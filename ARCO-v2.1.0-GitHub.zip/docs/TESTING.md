# 2.1.0 測試紀錄

測試日期：2026-10-02。這份文件記錄實際執行範圍，不將模擬環境當成上線環境。

## 已執行

| 測試 | 範圍 |
| --- | --- |
| 題庫結構 | 100 級、每級 10 題、共 1,000 個唯一 ID；四個不同選項、正確答案索引、解析、教材與實作 schema。 |
| 抽樣壓力測試 | 1,000 份試卷均為 15 題，五個範圍各 3 題；同卷無重複 ID 或題幹；選項順序與正解對應正確。 |
| 跨次避重 | 連續 20 次完成測驗，共 300 題沒有重複；另測試 60 次重測後題池耗盡時仍不會同卷重複。 |
| 建議起點 | 第 1、20、40、60、80、100 級，及前段缺口不能被後段答對覆蓋的情況。 |
| 重複送出 | 舊題目 token、連續 next 呼叫、重複採用結果不會多記分或改寫下一題。 |
| 開放範圍 | 建議 40 後第 1–40 級都可直接進入；第 41 級仍鎖定，40 級 7 題不解鎖、8 題解鎖。 |
| 舊課與重測 | 回頭挑戰失敗不收回開放範圍；重測建議較低，仍保留先前已採用範圍。 |
| 資料格式 | 舊版 placement、合法成績、錯題、已見題目與 v3 匯出／匯入的格式相容及清洗。 |
| 介面 | 100 個課程與實作面板；320、360、390、768px 的主要頁面及測驗無整頁橫向溢出。 |
| AI 對戰 | 三種對手可啟動，完成 10 題標準對戰、再來一局與離開。 |
| 雙人對戰 | 實際 BroadcastChannel 在兩個瀏覽器分頁同步 10 題與選項、雙方準備、分數、再來一局、斷線停止。 |
| 離線請求 | 測試過的單人與 AI 流程沒有外部網路請求或未捕捉的 JavaScript 例外。 |
| 建置與圖示 | JavaScript 語法檢查、完整 HTML 建置，以及 src/icons.js 與 assets/icons.json 一致性。 |

## 環境與限制

無介面 Chromium，測試 HTML 透過 `page.set_content` 注入。原生 HTTP 導航嘗試回傳 `ERR_BLOCKED_BY_ADMINISTRATOR`，未修改或規避環境政策。

瀏覽器測試使用測試程式建立的記憶體 localStorage 替身；它不會寫入發布的 HTML。資料還原測試驗證的是序列化、清洗與還原邏輯，不是原生瀏覽器關閉／重開後的持久儲存。AI 計時測試使用 Playwright 虛擬時鐘。

匯出測試讀取程式產生的 JSON Blob，匯入測試使用檔案輸入模擬，不聲稱已驗證正常瀏覽器的下載對話框。雙人測試使用真正的 BroadcastChannel，但不是跨裝置 WebRTC。

以下尚未完成上線實測：

- GitHub Pages 的實際部署與正式網址導覽。
- 原生 localStorage 的重新整理、關閉／重開與跨次保存。
- 一般使用者瀏覽器中的原生下載。
- 跨裝置、跨網路與行動網路的 WebRTC。
- 真人音準、節奏或演奏能力評分。
- 由獨立音樂教師逐題覆核及測驗統計校準。

發布後請依 [DEPLOYMENT.md](DEPLOYMENT.md) 完成相應檢查。

## 重新執行

```bash
python build.py
python tests/validate_content.py
node tests/placement.test.cjs
```

瀏覽器測試另需 Playwright 與 Chromium，腳本預設 Chromium 位於 `/usr/bin/chromium`，其他平台請改成實際位置或使用 Playwright 管理的瀏覽器。此兩個腳本是模擬環境回歸測試，不會取代上線檢查。

```bash
python tests/browser_test.py
python tests/duel_local_test.py
```

機器可讀結果：`content-report.json`、`placement-report.json`、`browser-report.json`、`duel-local-report.json`，皆位於 tests 資料夾。
