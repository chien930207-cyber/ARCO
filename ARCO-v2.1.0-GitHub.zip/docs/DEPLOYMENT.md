# GitHub Pages 部署與上線檢查

## 從網頁上傳，不需要 GitHub Desktop

解壓發布包後，將內容拖到 repository 的 **Add file → Upload files**，再按 **Commit changes**。根目錄應直接看到 `index.html`、`README.md`、`src`、`assets` 與 `docs`，而不是只有 ZIP 或一個外層資料夾。

到 **Settings → Pages**，選擇 **Deploy from a branch → main → / (root)**，儲存後等待平台顯示網站網址。不要選 `docs`；本專案的首頁不在 `docs` 資料夾。

`.nojekyll` 是空白標記檔，不需要寫入內容。瀏覽器若沒有上傳這個檔案，可在 GitHub 的 Add file → Create new file 建立同名檔案，再提交。

官方說明：
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## 更新

一般更新只需重新上傳新版 `index.html`；有修改品牌資產時，也同步更新 `assets` 與 `favicon.ico`。維護公開原始碼時，README、src 與 docs 也應更新，避免原始碼與已發布版本不同。

本專案不包含 service worker，不會額外快取舊版程式。若暫時看見舊畫面，先確認最新部署完成，再重新整理或使用無痕視窗檢查。請勿因而先清除有進度的瀏覽資料。

## 首次上線必測

- 用一般 Chrome 或 Edge 開啟網站，確認首次邀請出現，完整測驗只有 15 題。
- 完成並採用程度測驗，記下開放範圍；重新整理或關閉分頁再開啟，確認範圍仍在。重測也應優先更換題目。
- 在已開放範圍內，直接點選前段與邊界級數，確認不用先通關；邊界後的課程仍依 8 / 10 晉級。
- 匯出 JSON，再於另一個瀏覽器匯入，確認課程成績、測驗範圍與避重紀錄正確。
- 點選琴鍵與教學試聽，確認音訊播放。手機可能需要使用者先點選才能啟用聲音。
- 使用兩台不同裝置，開啟同一發布版本，選「網際網路連線」，完成一局、再來一局並測試離線。

以上原生瀏覽器與跨裝置檢查尚未由此建置環境完成，不應將雙分頁測試視為等效驗證。

## 常見問題

**網址顯示 README，沒有網站**：檢查根目錄是否存在名稱完全為 `index.html` 的檔案。不要把發布檔只命名為 `ARCO-v2.1.0.html`。

**頁面 404**：檢查 Pages 是否已選定 main / root、部署是否完成，以及使用的是 Pages 提供的網址，不是 repository 的檔案網址。

**開放範圍不見**：本機檔案、GitHub Pages、不同瀏覽器或不同網站來源不會自動共用 localStorage。從原環境匯出進度，再於新網站匯入。

**測驗又出現舊題**：避重以目前瀏覽器的已見題目紀錄為準；更換環境、清除資料，或同難度題池用盡，都可能再次出題。題池用盡時會先重用最久未見的題目。

**真人對戰連不上**：兩邊應使用同一版、同一連線模式；確認房主分頁仍開著。網路防火牆或 NAT 可能阻擋 WebRTC，不能僅以單人功能正常判定連線一定可用。本專案沒有提供私人 TURN 服務。參考 https://peerjs.com/client/faq 。

**不想做初始測驗**：可從第一級開始。測驗邀請不會強迫完成；後續可從首頁或設定重測。
