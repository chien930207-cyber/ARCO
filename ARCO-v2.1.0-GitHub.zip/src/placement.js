"use strict";
/** 15-question stratified placement. All scoring is local and uncalibrated. */
window.ArcoPlacement = (() => {
  const A = window.ARCO, E = A.escape, $ = s => document.querySelector(s);
  const TOTAL = 15;
  const TIERS = [
    { title: '識譜與節奏', from: 1, to: 20 },
    { title: '音程與調性', from: 21, to: 40 },
    { title: '和弦與進行', from: 41, to: 60 },
    { title: '延伸與調式', from: 61, to: 80 },
    { title: '樂句與進階和聲', from: 81, to: 100 }
  ];
  let run = null;
  const fingerprint = q => q.prompt.normalize('NFKC').replace(/\s+/g, '').toLowerCase();
  const allQuestions = [...A.Q.values()];
  const token = () => crypto.getRandomValues(new Uint32Array(3)).join('-');
  function seen() { A.getState().onboardingSeen = true; A.save(); }
  function close() { for (const id of ['welcome', 'settings']) { const d = $('#' + id); if (d?.open) d.close(); } }
  function welcome() {
    const d = $('#welcome');
    if (A.getState().onboardingSeen || ['#placement', '#quiz'].includes(location.hash) || !d) return;
    d.innerHTML = `<div class="welcome-art" aria-hidden="true"><span>ARCO</span><div class="welcome-emblem">${A.brandMark('large')}</div><div class="welcome-art-caption">把樂理，帶進演奏。</div></div><div class="welcome-copy"><button class="icon-button welcome-close" data-action="placement-skip" aria-label="關閉程度測驗邀請">${A.icon('close')}</button><p class="subtle-label">第一次來，先找到起點</p><h1 id="welcome-title">已經會的，<br>不用再從頭學。</h1><p>15 題，依五個難度範圍隨機抽樣。不限時；不熟悉的觀念可以直接略過，不必猜答案。</p><div class="welcome-facts"><span>${A.icon('shuffle')}重測換題</span><span>${A.icon('unlock')}前段直接開放</span><span>${A.icon('check')}保留原有成績</span></div><button class="btn" data-action="placement-start" autofocus>開始 15 題程度測驗 ${A.icon('arrow')}</button><button class="btn secondary" data-action="placement-beginner">先從第一級開始</button><button class="text-button" data-action="placement-skip">先看看課程，之後再測</button><p class="hint">例如建議第 40 級，採用後第 1–40 級都能直接進入。測驗用來建議學習起點，不是正式能力檢定。</p></div>`;
    d.showModal();
  }
  /** Prefer never-exposed questions. Only reuse least-recently seen items when
   *  this tier/type pool has no unseen item, with prompt-level deduplication. */
  function sample() {
    const history = A.getState().placementSeen || [];
    const seenRank = new Map();
    history.forEach((id, i) => { const q = A.Q.get(id); if (q) seenRank.set(fingerprint(q), i); });
    const usedIds = new Set(), usedPrompts = new Set(), questions = [];
    TIERS.forEach((tier, tierIndex) => {
      const usedLevels = new Set(), usedChapters = new Set();
      const pool = allQuestions.filter(q => q.level >= tier.from && q.level <= tier.to);
      const types = [q => q.difficulty === 1, q => q.difficulty === 2, q => q.difficulty >= 3];
      types.forEach(matchesType => {
        let candidates = pool.filter(q => matchesType(q) && !usedIds.has(q.id) && !usedPrompts.has(fingerprint(q)));
        if (!candidates.length) throw Error('程度測驗題池不足，請重新載入完整網站檔案。');
        const fresh = candidates.filter(q => !seenRank.has(fingerprint(q)));
        if (fresh.length) candidates = fresh;
        else { const oldest = Math.min(...candidates.map(q => seenRank.get(fingerprint(q)))); candidates = candidates.filter(q => seenRank.get(fingerprint(q)) === oldest); }
        const novelLevel = candidates.filter(q => !usedLevels.has(q.level));
        if (novelLevel.length) candidates = novelLevel;
        const novelChapter = candidates.filter(q => !usedChapters.has(Math.floor((q.level - 1) / 10)));
        if (novelChapter.length) candidates = novelChapter;
        const q = A.shuffle(candidates)[0];
        questions.push({ ...q, tier: tierIndex, band: Math.floor((q.level - 1) / 10), order: A.shuffle([0, 1, 2, 3]) });
        usedIds.add(q.id); usedPrompts.add(fingerprint(q)); usedLevels.add(q.level); usedChapters.add(Math.floor((q.level - 1) / 10));
      });
    });
    return questions;
  }
  function recordExposure() {
    const q = current();
    if (!q || run.exposed.has(q.id)) return;
    run.exposed.add(q.id);
    const s = A.getState();
    s.placementSeen = [...(s.placementSeen || []).filter(id => id !== q.id), q.id].slice(-1000);
    A.save();
  }
  function start() {
    if (active() && !confirm('重新開始會放棄目前未完成的測驗，並重新抽題。繼續嗎？')) return;
    try {
      const questions = sample();
      seen(); close(); A.stopAudio();
      run = { id: token(), phase: 'test', questions, index: 0, selection: null, responses: [],
        committed: new Set(), exposed: new Set(), accepted: false, busy: false };
      A.go('placement');
    } catch (err) { A.notify(err.message || '無法開始測驗，請重新載入網站。'); }
  }
  function current() { return run?.questions[run.index]; }
  function questionToken() { return run && current() ? run.id + ':' + current().id : ''; }
  function answer(choice, expectedToken = questionToken()) {
    if (!active() || run.busy || expectedToken !== questionToken() || run.committed.has(current().id) || !Number.isInteger(choice) || choice < -1 || choice > 3) return;
    run.selection = choice; render(); $('#placement-next')?.focus({ preventScroll: true });
  }
  function next(expectedToken = questionToken()) {
    if (!active() || run.busy || expectedToken !== questionToken() || run.selection === null) return;
    const q = current();
    if (!q || run.committed.has(q.id)) return;
    run.busy = true; run.committed.add(q.id);
    run.responses.push({ qid: q.id, level: q.level, band: q.band, tier: q.tier, choice: run.selection, correct: run.selection === q.correct });
    run.index++; run.selection = null; A.stopAudio();
    if (run.responses.length === TOTAL) finish();
    run.busy = false; render(); $('#placement-title')?.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
  function finish() {
    run.phase = 'result';
    run.bandScores = TIERS.map((tier, i) => ({ ...tier, correct: run.responses.filter(r => r.tier === i && r.correct).length, total: 3 }));
    let consecutive = 0;
    for (const tier of run.bandScores) { if (tier.correct < 2) break; consecutive++; }
    // A later correct answer does not erase an earlier prerequisite gap.
    run.start = consecutive === 0 ? 1 : consecutive * 20;
    run.correct = run.responses.filter(r => r.correct).length;
    run.cautious = run.bandScores.slice(consecutive + 1).some(t => t.correct >= 2);
  }
  function render() {
    if (!run) {
      A.setContent(`<div class="placement-intro"><div class="feature-mark">${A.icon('placement')}</div><h1>15 題，找到下一步。</h1><p>五個難度範圍，每個隨機抽 3 題，從觀念到應用。重測優先換成沒看過的題目；同次測驗不重複，選項順序也會重排。</p><p>採用結果後，建議級數以前的課程可直接進入，包括建議的那一級。不會把未做過的練習記成滿分。</p><div class="studio-actions"><button class="btn" data-action="placement-start">開始 15 題程度測驗 ${A.icon('arrow')}</button><a class="text-button" href="#home">返回練習室</a></div><p class="hint">短版抽樣不等於正式分級。你也可以從第 1 級開始，依每課 8 / 10 的門檻往前練。</p></div>`);
      return;
    }
    if (run.phase === 'result') { result(); return; }
    recordExposure();
    const q = current(), t = questionToken(), selected = run.selection !== null, tier = TIERS[q.tier];
    A.setContent(`<div class="quiz-wrap placement-wrap"><div class="quiz-top"><button class="text-button" data-action="placement-cancel">${A.icon('back')}離開測驗</button><span class="badge">${A.icon('shuffle')}分層隨機抽測 · 不限時</span></div><div class="placement-progress"><span>第 ${run.index + 1} / ${TOTAL} 題</span><span>${E(tier.title)} · 範圍 ${tier.from}–${tier.to} 級</span></div><div class="placement-meter" role="progressbar" aria-label="程度測驗進度" aria-valuemin="0" aria-valuemax="15" aria-valuenow="${run.responses.length}">${Array.from({length: TOTAL}, (_, i) => `<i class="${i < run.index ? 'done' : i === run.index ? 'current' : ''}"></i>`).join('')}</div><article class="quiz-card"><div class="question-label"><span>${E(A.D.chapters[q.band].title)}</span><span>${E(q.phase || '觀念應用')}</span></div><h1 id="placement-title" tabindex="-1">${E(q.prompt)}</h1>${q.staff ? A.staffView(q.staff) : ''}${q.audio ? A.audioCard(q.audio, 'question', q.id) : ''}<div class="options" role="group" aria-label="程度測驗選項">${q.order.map((c, i) => `<button class="option ${run.selection === c ? 'current' : ''}" data-action="placement-answer" data-choice="${c}" data-token="${E(t)}" aria-pressed="${run.selection === c}"><span class="letter">${'ABCD'[i]}</span><span>${E(q.options[c])}</span></button>`).join('')}</div><div class="quiz-bottom"><button class="text-button ${run.selection === -1 ? 'selected-unknown' : ''}" data-action="placement-unknown" data-token="${E(t)}">${run.selection === -1 ? '已選：還不熟悉' : '還不熟悉這個觀念'}</button><button id="placement-next" class="btn" data-action="placement-next" data-token="${E(t)}" ${selected ? '' : 'disabled'}>${run.index === TOTAL - 1 ? '查看建議起點' : '確認，下一題'} ${A.icon('arrow')}</button></div><p class="hint">確認前可更改選擇；送出後不重複計分。答錯不計入錯題本，測驗結束再一起看解析。</p></article></div>`);
  }
  function result() {
    const weak = [...new Set(run.responses.filter(r => !r.correct).map(r => r.level))];
    const previous = A.getState().placement?.start || 1, effective = Math.max(previous, run.start);
    A.setContent(`<div class="quiz-wrap placement-result"><section class="result-hero"><div class="score-circle"><strong>${run.start}</strong><span>建議起始級數</span></div><div><p class="subtle-label">適合你的下一步</p><h1>${run.start === 1 ? '先把基礎接起來。' : '從這裡接著練。'}</h1><p>${run.correct} / ${TOTAL} 題答對。${run.cautious ? '前段仍有缺口，建議先補穩，再往後練。' : '以各難度範圍的表現，建議一個保守的學習起點。'}</p><button class="btn light" data-action="placement-accept" data-run="${E(run.id)}">採用建議，前往第 ${run.start} 級 ${A.icon('arrow')}</button></div></section><section class="placement-access"><div class="feature-mark">${A.icon('unlock')}</div><div><h2>第 1–${effective} 級，可直接進入。</h2><p>不用先闖完前面的關卡。採用後可從課程列表任選第 1–${effective} 級，閱讀、實作或挑戰都可以。${effective < 100 ? `第 ${effective + 1} 級起，依每級答對 8 題的規則繼續解鎖。` : '全部 100 級皆已開放，可自由挑選需要的主題。'}</p>${previous > run.start ? `<p class="hint">先前已開放至第 ${previous} 級，這次重測不會把舊課程重新鎖住。</p>` : ''}</div></section><div class="placement-explainer"><h2>${E(A.lesson(run.start).title)}</h2><div class="placement-tier-results">${run.bandScores.map(b => `<div><span>${b.from}–${b.to} 級</span><strong>${b.correct}<small> / 3</small></strong><span>${E(b.title)}</span><span class="tier-verdict">${A.icon(b.correct >= 2 ? 'check' : 'book')}${b.correct >= 2 ? '抽測達標' : '建議回看'}</span></div>`).join('')}</div><p>每個範圍答對至少 2 題，才作為往後建議的依據；前段有缺口時，不會因後段答對就直接跳過。課程標示為「測驗開放」，不等於已通過或已精通。</p><p class="hint">15 題無法涵蓋每個主題，也不測量真實演奏、聽寫或視唱能力。實際操作有困難時，隨時回前面的課程補強。</p></div><section class="placement-review"><h2>這次值得回看的主題</h2>${weak.length ? `<div class="review-topic-list">${weak.map(i => `<span>第 ${i} 級 ${E(A.lesson(i).title)}</span>`).join('')}</div>` : '<p>這次抽測沒有答錯。接著試試互動實作，確認觀念也能用在演奏裡。</p>'}<details><summary>查看 15 題的答案與說明</summary>${run.responses.map((r, i) => { const q = A.Q.get(r.qid); return `<div class="placement-answer"><span class="badge">${r.correct ? '答對' : '待補強'}</span><h3>${i + 1}. ${E(q.prompt)}</h3><p>正確答案：${E(q.options[q.correct])}</p><p class="muted">${E(q.explanation)}</p></div>`; }).join('')}</details></section><div class="studio-actions"><button class="btn secondary" data-action="placement-start">${A.icon('refresh')}換一組題目重測</button><button class="text-button" data-action="placement-discard">暫不採用，保留原進度</button></div></div>`);
  }
  function accept(expectedRun = run?.id) {
    if (!run || run.phase !== 'result' || run.accepted || expectedRun !== run.id) return;
    run.accepted = true;
    const s = A.getState(), target = run.start;
    s.placement = { start: Math.max(s.placement?.start || 1, target), suggested: target, method: 'stratified-15-v1', at: Date.now(), total: TOTAL, correct: run.correct, weak: [...new Set(run.responses.filter(r => !r.correct).map(r => r.level))], bandScores: run.bandScores.map(t => t.correct) };
    s.testMode = false; s.lastLevel = target; s.onboardingSeen = true;
    const openThrough = s.placement.start;
    run = null; A.save(); A.go('lesson/' + target);
    A.notify(`已開放第 1–${openThrough} 級，可直接點選進入；原有成績仍保留。`);
  }
  function active() { return !!run && run.phase === 'test'; }
  function leaveRoute() {
    if (active() && !confirm('離開程度測驗？未完成的結果不會更改起點；已看過的題目會留作下次抽題避重紀錄。')) return false;
    run = null; return true;
  }
  function action(a, el) {
    if (a === 'placement-start') start();
    else if (a === 'placement-skip') { seen(); close(); }
    else if (a === 'placement-beginner') { seen(); close(); A.getState().testMode = false; A.save(); A.go('lesson/1'); }
    else if (a === 'placement-answer') answer(Number(el.dataset.choice), el.dataset.token);
    else if (a === 'placement-unknown') answer(-1, el.dataset.token);
    else if (a === 'placement-next') next(el.dataset.token);
    else if (a === 'placement-accept') accept(el.dataset.run);
    else if (a === 'placement-cancel') { if (leaveRoute()) A.go('home'); }
    else if (a === 'placement-discard') { run = null; A.go('home'); }
    else if (a === 'placement-clear') {
      if (confirm('取消程度測驗開放的課程？未實際通過的前段課程可能重新鎖住；正式與測試成績仍保留。')) {
        A.getState().placement = null; A.save(); close(); A.go('home'); A.notify('已取消測驗開放，保留所有實際成績與抽題紀錄。');
      }
    }
  }
  document.addEventListener('keydown', e => {
    if (location.hash !== '#placement' || !active() || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.repeat || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('dialog[open]')) return;
    if (/^[1-4]$/.test(e.key)) { e.preventDefault(); answer(current().order[Number(e.key) - 1]); }
  });
  $('#welcome')?.addEventListener('cancel', seen);
  setTimeout(() => { if (location.hash === '#placement') render(); else welcome(); }, 0);
  return { welcome, start, render, action, active, leaveRoute, current, getRun: () => run, answer, next, accept, sample, questionToken, tiers: TIERS };
})();
