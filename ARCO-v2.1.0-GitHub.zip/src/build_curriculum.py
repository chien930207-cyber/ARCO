from pathlib import Path
import json, math, re, hashlib

ROOT = Path(__file__).resolve().parents[1]
CHAPTERS = [
 ('識譜的第一步','認識音名、譜表與時值。','Notation'),
 ('找到節奏感','把拍子、細分與重音分開聽。','Rhythm'),
 ('聽見音與音的距離','從度數到音程聽辨。','Intervals'),
 ('音階與調性','理解一組音如何圍繞主音。','Scales & keys'),
 ('把音組成和弦','三和弦、掛留與轉位。','Triads'),
 ('和弦如何往前走','和聲功能、終止與常見進行。','Harmony'),
 ('多一個音的表情','七和弦、延伸音與副屬和弦。','Seventh chords'),
 ('換一種音樂色彩','七種調式、五聲與藍調音階。','Modes'),
 ('讓樂句說話','動機、非和弦音與轉調。','Composition'),
 ('走進進階語彙','借用、替代、對稱音階與音列。','Advanced theory')
]
SOURCES = {
 'mt': {'title':'musictheory.net｜樂理課程目錄','url':'https://www.musictheory.net/lessons','kind':'教材'},
 'intervals': {'title':'Open Music Theory｜音程','url':'https://viva.pressbooks.pub/openmusictheory/chapter/intervals/','kind':'教材與譜例'},
 'compound': {'title':'Open Music Theory｜複拍子','url':'https://viva.pressbooks.pub/openmusictheory/chapter/compound-meters-and-time-signatures/','kind':'教材與聆聽'},
 'rhythm': {'title':'Open Music Theory｜節奏與拍子','url':'https://viva.pressbooks.pub/openmusictheory/part/rhythm-and-meter/','kind':'主題目錄'},
 'jazz': {'title':'Open Music Theory｜爵士樂理','url':'https://viva.pressbooks.pub/openmusictheory/part/jazz/','kind':'主題目錄'},
 'modes': {'title':'Open Music Theory｜調式與音階分析','url':'https://viva.pressbooks.pub/openmusictheory/chapter/analyzing-with-collections-scales-and-modes/','kind':'教材與譜例'},
 'tones': {'title':'Open Music Theory｜裝飾音','url':'https://viva.pressbooks.pub/openmusictheory/chapter/embellishing-tones/','kind':'教材與聆聽'},
 'secondary': {'title':'Open Music Theory｜暫時主音化','url':'https://viva.pressbooks.pub/openmusictheory/chapter/tonicization/','kind':'教材與聆聽'},
 'modulation': {'title':'Open Music Theory｜近系轉調','url':'https://viva.pressbooks.pub/openmusictheory/chapter/extended-tonicization-and-modulation-to-closely-related-keys/','kind':'教材與聆聽'},
 'mixture': {'title':'Open Music Theory｜調式混合','url':'https://viva.pressbooks.pub/openmusictheory/chapter/modal-mixture/','kind':'教材與聆聽'},
 'sub': {'title':'Open Music Theory｜和弦替代','url':'https://viva.pressbooks.pub/openmusictheory/chapter/substitutions/','kind':'教材與聆聽'},
 'neapolitan': {'title':'Open Music Theory｜拿坡里六和弦','url':'https://viva.pressbooks.pub/openmusictheory/chapter/bii6/','kind':'教材與聆聽'},
 'aug6': {'title':'Open Music Theory｜增六和弦','url':'https://viva.pressbooks.pub/openmusictheory/chapter/augmented-sixth-chords/','kind':'教材與聆聽'},
 'metric': {'title':'Open Music Theory｜二十世紀節奏技法','url':'https://viva.pressbooks.pub/openmusictheory/chapter/twentieth-century-rhythmic-techniques/','kind':'教材與聆聽'},
 'row': {'title':'Open Music Theory｜十二音技法','url':'https://viva.pressbooks.pub/openmusictheory/chapter/basics-of-twelve-tone-theory/','kind':'教材與聆聽'},
 'omt': {'title':'Open Music Theory｜完整教材','url':'https://viva.pressbooks.pub/openmusictheory/','kind':'教材目錄'},
 'ableton': {'title':'Ableton Learning Music｜繁體中文互動教材','url':'https://learningmusic.ableton.com/zh-Hant/','kind':'互動試聽'}
}
META = '''
1|七個音名|Note names|音名依序是 C、D、E、F、G、A、B，再回到 C。字母代表音的名稱；八度數字用來分辨高低，例如 C4 與 C5。|在鍵盤上找出兩個黑鍵左邊的白鍵，那就是 C。接著慢慢唱出 C 到 B。|字母順序從 A 開始，但初學鍵盤常先從 C 認音；這兩件事並不衝突。|mt
2|鍵盤與半音|Half steps|十二平均律中，相鄰琴鍵的距離是一個半音，黑鍵也算。兩個半音合成一個全音。E–F、B–C 之間沒有黑鍵。|從 C 往右逐鍵彈到下一個 C，數一數共移動幾次。|半音不等於「白鍵到黑鍵」；E 到 F 是白鍵到白鍵，仍是一個半音。|mt
3|升、降與還原|Accidentals|升記號 ♯ 升高半音；降記號 ♭ 降低半音。還原記號 ♮ 取消升降變化，不是固定往上或往下移。|比較 C、C♯、C，再比較 D、D♭、D。留意升降記號改變的是音高。|E♯ 與 F 在十二平均律中同音；有升記號的音不一定是黑鍵。|mt
4|高音譜表|Treble clef|高音譜表由下往上的五條線是 E4、G4、B4、D5、F5，四個間是 F4、A4、C5、E5。本課不加調號。|對照譜例，先找第二線 G4，再逐線、逐間往上或往下數。|高音譜號也叫 G 譜號，捲曲中心標出 G 所在的第二線。|mt
5|低音譜表|Bass clef|低音譜表由下往上的五條線是 G2、B2、D3、F3、A3，四個間是 A2、C3、E3、G3。本課不加調號。|先認第四線 F3，再試著讀出上下相鄰的音。|低音譜號右側的兩個點夾住第四線 F，因此也叫 F 譜號。|mt
6|音符的時值|Note values|音符時值彼此有固定比例。以四分音符為一拍時，全音符四拍、二分音符兩拍、八分音符半拍、十六分音符四分之一拍。|用一樣的拍速，依序拍一個二分音符、兩個四分音符、四個八分音符。|全音符不保證佔滿一小節；它是否剛好一小節，要看拍號。|mt
7|休止也有長度|Rests|休止符表示在指定時值內不發聲。休止時拍子仍繼續前進；四分休止符與四分音符長度相同。|用「拍、空、拍、空」練四拍，空拍時繼續默數。|整小節休止常用全休止符表示，即使那一小節不是四拍。|mt
8|讀懂拍號|Time signatures|簡單拍子中，上方數字是每小節拍數，下方數字標示一拍的音符單位。4/4 是每小節四個四分音符拍，3/4 則是三個。|分別數 1、2、3、4 與 1、2、3，感受每小節回到第一拍的位置。|拍號下方的 4 不是「四拍」，而是四分音符這個單位。|mt
9|附點的算法|Dotted notes|一個附點會增加原時值的一半；兩個附點再增加原時值的四分之一。因此單附點是原長度的 1.5 倍。|以四分音符為一拍，拍出附點四分加八分：1.5 拍加 0.5 拍。|附點放在音符後面；與斷奏用的小點不是同一種記號。|mt
10|連結線與圓滑線|Ties and slurs|連結線連接同音高的音符，時值相加，只在開頭發聲一次。圓滑線表示樂句或奏法上的連接，可涵蓋不同音高。|先彈兩次 C，再把兩個 C 連成一次長音，聽出起音數量的差別。|連結線可以跨小節線，因此長音能延續到下一小節。|mt
11|拍速與 BPM|Tempo and BPM|BPM 是每分鐘的拍數，還要知道哪種音符算一拍。四分音符 = 120 時，一個四分音符長 0.5 秒。|把節拍器設為四分音符 60 BPM，每次點擊隔一秒；再改為 120 比較。|同樣寫 60 BPM，四分音符與附點四分音符的設定會有不同細分。|rhythm
12|八分音符細分|Eighth-note subdivision|在四分音符為一拍的簡單拍子中，每拍平均分成兩個八分音符。可以數「1 and 2 and」。|腳踩四分拍，手每拍拍兩下；不要讓腳跟著加速。|把細分變多不等於把歌曲 BPM 調快。|rhythm
13|十六分音符細分|Sixteenth-note subdivision|一個四分音符可分成四個十六分音符。常見數法是 1 e and a，四個位置要平均。|慢速數一拍的四個位置，再只拍第 1 與第 4 個位置。|符尾或符槓增加，時值就減半；兩條符槓是十六分音符。|rhythm
14|三連音|Triplets|一般簡單拍子中，八分三連音把一個四分音符平均分成三份，三個合起來仍是一拍。|同一拍速，交替拍兩個平均八分音符與三個八分三連音。|三連音不是任何「三個音」；重點是三等分取代原本的二等分。|rhythm
15|6/8 的兩大拍|Compound meter|6/8 常以兩個附點四分音符為大拍，每大拍分成三個八分音符。它與 3/4 的總八分音符數相同，但分組不同。|交替數 6/8 的「1-la-li 2-la-li」與 3/4 的「1-and 2-and 3-and」。|6/8 與 3/4 都能裝六個八分音符，卻不代表聽起來相同。|compound
16|弱起小節|Pickup measures|樂句可以從不完整的小節開始，稱為弱起。先辨認音樂真正落在第一拍的位置，再往前計算起始音。|用一個八分音符引入下一小節的第一拍，感受「走進去」而非直接起跑。|弱起的第一個音不是第一拍；開頭有聲音不代表那裡就是強拍。|rhythm
17|切分音|Syncopation|切分把重音或延音放在原本較弱的位置，常跨過強拍。穩定的底拍仍在，才能聽見偏移。|腳踩穩定拍，手在每拍的 and 拍一下，再延續到下一個正拍。|切分可以靠休止、重音或連結線形成，不只靠某一種固定節奏型。|rhythm
18|Swing 的長短感|Swing rhythm|Swing 常把一對八分音符演成前長後短。三連音的前兩份加最後一份，是入門近似，實際比例會隨速度與風格改變。|比較平均的兩個八分音符與長短兩下，拍速保持不變。|Swing 不是永遠精準 2:1；更不能把所有演奏都硬套成附點八分加十六分。|jazz
19|不等長分組|Asymmetrical meter|5/8、7/8 等拍子可用 2 與 3 的組合分組。7/8 可以是 2+2+3，也可以是 3+2+2，重音位置不同。|用 2+2+3 數七個八分音符，再換成 3+2+2。|拍號相同不表示分組必定相同，符槓與重音能提供線索。|metric
20|三對二複節奏|Three against two|3:2 複節奏是在同一段時間裡，一個聲部平均演三下，另一個平均演兩下。可先分成六等份定位。|數六格，右手打第 1、3、5 格，左手打第 1、4 格。|兩個聲部各自都可以很平均；不整齊的是它們彼此交錯的位置。|rhythm
21|先數音程度數|Generic intervals|數音程度數時，起點與終點都要算。C 到 E 經過 C、D、E，所以是三度；升降記號不改變字母度數。|在譜上從一個音逐線、逐間數到另一個音，先不要急著判斷大小。|C 到 C 是一度而不是零度，因為度數採包含起點的算法。|intervals
22|大二度與小二度|Seconds|上行小二度是一個半音，大二度是兩個半音；兩者的字母名稱必須相鄰。C–D♭ 是小二度。|比較 C–D♭ 與 C–D，先唱出近的，再唱出稍遠的。|C–C♯ 雖然也是一個半音，依拼法卻是增一度，不是小二度。|intervals
23|大三度與小三度|Thirds|小三度是三個半音，大三度是四個半音。三度是辨認大、小三和弦的重要線索。|比較 C–E♭ 與 C–E，再各自加入 G。|C–D♯ 與 C–E♭ 在十二平均律中同音，但前者拼成增二度。|intervals
24|完全四度與五度|Perfect fourths and fifths|完全四度是五個半音，完全五度是七個半音。這兩類基本音程用「完全」而不是「大」或「小」。|從 C 彈到 F，再從 C 彈到 G，留意兩種距離。|所有白鍵四度不一定完全：F 到 B 是增四度。|intervals
25|六度與七度|Sixths and sevenths|小六度八個半音，大六度九個；小七度十個，大七度十一個。仍要先核對字母度數。|比較 C–B♭ 與 C–B，再讓上方音回到 C，感受差別。|大七度只差一個半音就到八度，這不代表它就是小二度。|intervals
26|八度與複音程|Compound intervals|超過八度的音程叫複音程。九度是八度加二度，十度是八度加三度；度數相加需減一。|先彈 C4–D4，再把 D 提高到 D5，比較二度與九度。|八度加八度是十五度，不是十六度。|intervals
27|增音程與減音程|Augmented and diminished intervals|大或完全音程擴大半音成為增音程；小或完全音程縮小半音成為減音程。拼法與半音數必須一起看。|比較 C–F、C–F♯ 與 C–G♭，讀名稱時留意字母。|增四度與減五度在十二平均律中都是六個半音，但名稱與和聲用法不同。|intervals
28|音程轉位|Interval inversion|簡單音程轉位時，度數相加為九。大變小、小變大、增變減，完全仍完全。|將 C4–E4 的 C 提高八度，變成 E4–C5，驗算三度轉為六度。|三度與六度互為轉位；這能幫助你快速檢查和弦配置。|intervals
29|同音異名|Enharmonic spelling|十二平均律中，不同音名可以對應相同琴鍵，例如 C♯ 與 D♭。但在譜上，它們表達的音階級數可能不同。|在鍵盤上找出 C♯ 與 D♭，再分別把它們放進 D 大調與 A♭ 大調。|雙升記號升高兩個半音；F𝄪 與 G 同音，仍保留 F 這個字母。|intervals
30|聽辨上行音程|Interval ear training|先聽第一個音，再辨認上方音與它的距離。本關每題都有合成試聽，可不限次重播；不必猜絕對音名。|聽完後試著唱回兩個音，再選音程名稱。|相對音感辨認的是音與音的關係；不需要先知道第一個音叫什麼。|intervals
31|大調音階|Major scales|大調相鄰音的距離為全、全、半、全、全、全、半。每個字母依序用一次，避免把升降拼法混亂。|慢彈 C 大調，再按相同距離從 G 出發，找出需要升高的音。|黑鍵數量不是大小調的判斷標準；F♯ 大調也遵守同一個大調公式。|mt
32|五度圈|Circle of fifths|沿五度圈順時針移動，主音上行完全五度；常見大調依序為 C、G、D、A、E、B、F♯。|從 C 開始，每次往上找完全五度，寫出前六個調名。|沿相反方向移動可視為上行完全四度，也就是調號逐步增加降號的方向。|mt
33|升號調號|Sharp key signatures|升號加入順序為 F、C、G、D、A、E、B。常見升號大調的主音在最後一個升號上方半音。|看到 F♯、C♯ 的調號，先由 C♯ 往上半音找出 D 大調。|調號中的升號影響各八度的同名音，不只影響符號畫出的那一個高度。|mt
34|降號調號|Flat key signatures|降號加入順序為 B、E、A、D、G、C、F。兩個以上降號的大調，倒數第二個降號就是主音；一個降號是 F 大調。|看到 B♭、E♭、A♭，找出倒數第二個降號 E♭。|升號與降號的加入順序互相倒過來。|mt
35|自然小調|Natural minor|自然小調的級數是 1、2、♭3、4、5、♭6、♭7，相鄰距離為全、半、全、全、半、全、全。|比較 C 大調與 C 自然小調，找出降低的第 3、6、7 級。|A 自然小調全用白鍵，但主音是 A，不是 C。|mt
36|關係大小調|Relative keys|關係大小調共用調號。大調第六級是關係小調主音；小調上方小三度是關係大調主音。|把 C 大調與 A 小調分別停在自己的主音，聽同一組音如何產生不同中心。|共用音符不代表樂曲的重心相同；主音與和聲仍要從音樂判斷。|mt
37|同主音大小調|Parallel keys|同主音大小調的主音相同，但調號不同，例如 C 大調與 C 小調。不要與共用調號的關係大小調混淆。|先彈 C–E–G，再彈 C–E♭–G，保持根音不變。|C 大調的關係小調是 A 小調，同主音小調則是 C 小調。|mt
38|和聲小調|Harmonic minor|和聲小調把自然小調的第七級升高半音。A 和聲小調包含 G♯，讓 E–G♯–B 成為大三和弦。|比較 Am–Em–Am 與 Am–E–Am，留意 G 與 G♯ 的差別。|和聲小調第六級到第七級形成增二度；這是它容易辨識的線索。|mt
39|旋律小調|Melodic minor|古典教材的旋律小調上行升高第六、七級，下行常回到自然小調。爵士旋律小調則通常上下行都保留升高的第六、七級。|比較 A–B–C–D–E–F♯–G♯–A 與 A 自然小調。|「旋律小調」在古典與爵士語境有不同慣例，題目必須先說清楚。|mt
40|首調唱名與級數|Movable do|本課採大調首調唱名：主音為 do，依序 re、mi、fa、sol、la、ti。換調後唱名對應的實際音名會改變。|把 C 大調的 do–mi–sol 移到 G 大調，唱名保持不變。|固定唱名與首調唱名是不同系統；看到 do 不一定永遠等於 C。|mt
41|大三和弦|Major triads|大三和弦由根音、大三度、完全五度組成，半音位置是 0、4、7。先確認根音，再找三音與五音。|依序彈 C、E、G，再一起彈；聽出分解和弦與同時發聲的關係。|根音是和弦命名的基礎，但不一定是實際最低音。|mt
42|小三和弦|Minor triads|小三和弦由根音、小三度、完全五度組成，半音位置是 0、3、7。與同根大三和弦只差三音。|在 C–E–G 與 C–E♭–G 之間切換，保持 C 與 G 不動。|小三和弦不必然表示悲傷；情緒還受速度、配器與前後文影響。|mt
43|減三和弦|Diminished triads|減三和弦由根音、小三度、減五度組成，半音位置是 0、3、6，兩層都是小三度。|比較 B–D–F 與 B–D–F♯，聽五音降低的效果。|自然大調第七級上疊出的三和弦就是減三和弦。|mt
44|增三和弦|Augmented triads|增三和弦由根音、大三度、增五度組成，半音位置是 0、4、8，兩層都是大三度。|比較 C–E–G 與 C–E–G♯，只改變五音。|增三和弦把十二個半音平均分成三份，因此具有對稱性。|mt
45|Sus 掛留和弦|Suspended chords|流行和弦符號中的 sus4 通常以四音取代三音，sus2 以二音取代三音。Csus4 為 C–F–G。|彈 Csus4 再回 C，讓 F 下行到 E。|流行符號 sus 不保證符合古典掛留音的預備與解決規則。|jazz
46|五度和弦|Power chords|C5 一般指 C 與 G，可加八度 C；沒有三音，所以本身不區分大、小三和弦。|用 C–G、F–C、G–D 彈一段進行，留意和弦性質的留白。|失真吉他常用五度和弦，但「5」不是指要彈五個音。|jazz
47|Add 附加音|Added-note chords|Add 表示在基礎和弦上加入指定音，並不自動加入七音。Cadd9 是 C–E–G 加 D。|比較 C、Cadd9 與 C9；後者通常還包含 B♭。|Cadd9 與 Csus2 都有 D，但 Cadd9 保留三音 E。|jazz
48|第一轉位|First inversion|三和弦以三音為最低音時，是第一轉位。C 和弦的 E–G–C 是第一轉位，根音仍然是 C。|右手保留 C 大三和弦，將低音改成 E，聽低音改變的效果。|古典數字低音常把第一轉位簡記為 6，並不是加入六音。|mt
49|第二轉位|Second inversion|三和弦以五音為最低音時，是第二轉位。C 和弦可寫成 G–C–E，根音仍為 C。|比較 C–E–G、E–G–C、G–C–E 三種低音位置。|數字低音 6/4 指低音上方的音程，不是拍號。|mt
50|斜線和弦|Slash chords|C/E 的斜線左側是和弦，右側是指定低音。低音可以是和弦內音，也可能是和弦外音。|用 C、C/B、Am 排出 C–B–A 的低音線，其他聲部保持簡單。|C/E 與古典羅馬數字 V/V 的斜線意思不同，後者表示副屬關係。|jazz
51|大調順階三和弦|Diatonic triads|只用大調音階的音，從每一級疊三度，可得大、小、小、大、大、小、減七種順階三和弦。|在 C 大調彈 C、Dm、Em、F、G、Am、Bdim。|同一個音階裡的三和弦，不會全部都是大三和弦。|mt
52|羅馬數字和弦|Roman numerals|羅馬數字表示根音級數，大小寫表示和弦性質。本課大調用 I、ii、iii、IV、V、vi、vii°。|把 C–Am–F–G 寫成 I–vi–IV–V，再移到 G 大調。|羅馬數字能保留和弦關係，所以比只記實際和弦名更適合移調。|mt
53|主、前屬與屬功能|Harmonic function|在基本功能和聲中，主和弦提供調性中心，前屬和弦常引向屬，屬再傾向主。典型模型為 I–IV–V–I。|彈 C–F–G–C，每次停在不同位置，感受句子是否需要繼續。|功能依語境判斷，不能把任何和弦都永久貼上一種情緒標籤。|omt
54|完全正格終止|Perfect authentic cadence|古典完全正格終止要求 V（或 V7）到 I，兩個和弦根音位置，且最後最高聲部落在主音。|用低音 G→C、最高聲部 B→C，做出清楚的 C 大調句尾。|只有 V–I 還不足以判定完全正格終止，低音與最高聲部也要檢查。|mt
55|半終止|Half cadence|樂句停在屬和弦 V，形成半終止，常有暫時停頓、仍待回應的感覺。判斷時要看它是否真是句尾。|彈 C–F–G，停在 G，接著再彈一段回到 C。|「半」不是指演到一半拍，而是終止的開放性。|mt
56|變格終止|Plagal cadence|基本變格終止是 IV–I，也就是下屬到主。本課先以大調根音位置理解這種句尾進行。|比較 F–C 與 G–C，聽兩種回到 C 的方式。|變格終止常被連結到 Amen 結尾，但不只出現在宗教音樂。|mt
57|阻礙終止|Deceptive cadence|大調常見阻礙終止是 V–vi：屬和弦原本似乎要回 I，卻轉到 vi，讓樂句延續。|在 C–F–G 後，先接 C，再改接 Am，比較期待的落差。|vi 和 I 共享兩個和弦音，讓這種意外轉向仍保有連貫性。|mt
58|I–V–vi–IV|Four-chord progression|這組大調進行依序是主、屬、第六級小和弦、下屬。在 C 大調為 C–G–Am–F。|先彈每小節一個和弦，再保持和弦不變，改變節奏與旋律。|共用同一組和弦不表示是同一首歌；旋律、節奏與結構仍可完全不同。|ableton
59|ii–V–I|Two five one|大調爵士 ii–V–I 常用 ii7–V7–Imaj7。在 C 大調是 Dm7–G7–Cmaj7。|先彈三和弦 Dm–G–C，再加入七音聽色彩的改變。|這個進行的根音每次下行五度，也可視為上行四度。|jazz
60|聲部進行|Voice leading|把每個聲部視為一條旋律，換和弦時可保留共同音，其他音就近移動。本課練最小移動，不把它當成所有風格的唯一規則。|由 C–E–G 移到 C–F–A，保留 C，讓 E→F、G→A。|和弦名稱不變時，換配置也可能讓內聲部產生一條新旋律。|mt
61|大七和弦|Major seventh chords|大七和弦在大三和弦上加大七度，半音位置 0、4、7、11。Cmaj7 是 C–E–G–B。|比較 C 與 Cmaj7，讓新增的 B 緩慢回到 C。|和弦符號 maj7 的 maj 指七度性質，不是單純寫「這是大和弦」。|mt
62|屬七和弦|Dominant seventh chords|屬七型和弦由大三和弦加小七度，半音位置 0、4、7、10。C7 是 C–E–G–B♭。|彈 G7–C，聽 B→C 與 F→E 的移動。|屬七型是和弦結構；它出現在歌曲裡時，不一定正好是原調的第五級。|mt
63|小七和弦|Minor seventh chords|小七和弦由小三和弦加小七度，半音位置 0、3、7、10。Cm7 是 C–E♭–G–B♭。|比較 Cm 與 Cm7，再放入 Dm7–G7–Cmaj7。|m7 與 maj7 不能只看最後的 7；三音與七音都要辨認。|mt
64|半減七和弦|Half-diminished seventh|半減七和弦由減三和弦加小七度，公式 1、♭3、♭5、♭7，可寫 m7♭5 或 ø7。|比較 B–D–F–A 與 B–D–F–A♭，聽最後一個音的差別。|Bø7 是 C 大調第七級上的順階七和弦。|mt
65|全減七和弦|Diminished seventh|全減七和弦由減三和弦加減七度，半音位置 0、3、6、9。例如 C°7 正確拼法是 C–E♭–G♭–B𝄫。|在 C°7 的四個音之間，每次上行小三度，最後回到八度 C。|C°7 的七音寫 B𝄫，雖與 A 同音，卻不能忽略它作為七音的拼法。|mt
66|小大七和弦|Minor-major seventh|小大七和弦由小三和弦加大七度，公式 1、♭3、5、7。Cm(maj7) 是 C–E♭–G–B。|保留 C、E♭、G，把七音從 B♭ 升到 B，比較小七與小大七。|旋律小調或和聲小調主音上的七和弦，都可形成小大七和弦。|jazz
67|七和弦的轉位|Seventh-chord inversions|七和弦有根音位置與三種轉位。三音、五音、七音在最低音，分別是第一、第二、第三轉位。|固定 Cmaj7 的四個音，輪流用 C、E、G、B 當低音。|第三轉位是七和弦才有的配置；三和弦沒有第四個和弦音可放低音。|mt
68|九、十一與十三音|Chord extensions|九、十一、十三度是二、四、六度提高八度的稱呼。C9 通常包含小七音；Cmaj9 則包含大七音。|比較 C7 與 C9，先只增加 D，避免一次塞入太多音。|實際配置常省略五音或某些延伸音；和弦符號不是把全部音一口氣按下的命令。|jazz
69|導引音|Guide tones|爵士和聲中，三音與七音常稱為導引音，能清楚表達和弦性質。ii–V–I 的導引音常以半音或共同音銜接。|只彈 Dm7 的 F、C，接 G7 的 F、B，再接 Cmaj7 的 E、B。|只用兩個導引音，配上貝斯根音，仍可能清楚聽出和聲進行。|jazz
70|副屬和弦|Secondary dominants|副屬和弦把調內某個非主和弦暫時當作目標。C 大調 D7–G 的 D7 是 V7/V，因為它是 G 的屬七和弦。|在 C–G 之間插入 D7，再聽它如何推向 G。|暫時主音化不一定形成完整轉調；新主音需要更長或更明確的建立。|secondary
71|Ionian 調式|Ionian mode|Ionian 的公式與大調相同：1、2、3、4、5、6、7。辨識時也要確認哪個音是中心。|用 C 當持續低音，彈 C 大調音階，並在 C 結束。|同一組白鍵可形成不同調式，關鍵不是從哪個鍵快速滑過，而是聽覺中心。|modes
72|Dorian 調式|Dorian mode|Dorian 是 1、2、♭3、4、5、6、♭7。與自然小調相比，第六級高半音，是常用辨認線索。|在 Dm 上比較 B 與 B♭，留意 D Dorian 的大六度 B。|D Dorian 與 C 大調共用音，但以 D 為中心。|modes
73|Phrygian 調式|Phrygian mode|Phrygian 是 1、♭2、♭3、4、5、♭6、♭7。主音上方的小二度是鮮明特色。|用 E 當低音，在 E 與 F 間做短句，最後停回 E。|E Phrygian 全用白鍵；低二級的色彩不需要額外黑鍵才能出現。|modes
74|Lydian 調式|Lydian mode|Lydian 是 1、2、3、♯4、5、6、7。與大調相比，第四級升高半音。|在 Cmaj7 上分別彈 F 與 F♯，比較兩種第四級。|F Lydian 全用白鍵，其中的 B 是相對 F 的升四級。|modes
75|Mixolydian 調式|Mixolydian mode|Mixolydian 是 1、2、3、4、5、6、♭7。與大調相比，第七級降低半音，常與屬七型和弦搭配。|用 G 作中心，彈白鍵 G 到 G，留意 F 而不是 F♯。|屬七型和弦可以是穩定的調式中心，不一定立刻解決到另一個主音。|modes
76|Aeolian 調式|Aeolian mode|Aeolian 與自然小調相同：1、2、♭3、4、5、♭6、♭7。不要把升七級的和聲小調混進來。|固定 A 低音，彈白鍵 A 到 A，反覆停回 A。|Aeolian 與 Dorian 只差第六級，卻會影響許多可用和弦的色彩。|modes
77|Locrian 調式|Locrian mode|Locrian 是 1、♭2、♭3、4、♭5、♭6、♭7。主音上方的五度是減五度，主三和弦是減三和弦。|以 B 作低音，彈 B–D–F，再比較把 F 提高到 F♯ 的效果。|七種自然調式中，只有 Locrian 的主三和弦含減五度。|modes
78|大調五聲音階|Major pentatonic|大調五聲音階取 1、2、3、5、6，省略大調第四與第七級。C 大調五聲為 C、D、E、G、A。|只用這五個音創作兩小節旋律，試著在 C 結束。|這種大調五聲音階的相鄰音中沒有半音。|ableton
79|小調五聲音階|Minor pentatonic|小調五聲音階取 1、♭3、4、5、♭7。A 小調五聲為 A、C、D、E、G。|在 Am 伴奏上只用 A、C、D、E、G，先練短句，不急著跑音階。|A 小調五聲與 C 大調五聲共用音，差別仍在主音中心。|ableton
80|小調藍調音階|Minor blues scale|常見小調藍調音階是在小調五聲中加入 ♭5：1、♭3、4、♭5、5、♭7。|在 C 小調五聲中加入 G♭，試著由 F 經 G♭ 走向 G。|真正的 blue notes 可透過推弦或滑音落在鋼琴固定音高之間；六音公式只是入門模型。|jazz
81|音樂動機|Motifs|動機是能被辨認的短小節奏或音高材料。重複、移位、增值與減值都可讓它在樂句中發展。|用三個音做一個節奏型，再只改音高，保留節奏讓聽者認得它。|動機不一定是一整段旋律；短短一個節奏也能有辨識度。|omt
82|經過音|Passing tones|經過音用同方向的級進連接兩個和弦音，例如 C 和弦中的 C–D–E，D 是經過音。|在 C 與 E 之間加入 D，讓跳進變成平滑的線條。|經過音可以在弱拍，也可能是強拍經過音；節拍位置不是唯一判準。|tones
83|鄰音|Neighbor tones|鄰音從一個和弦音級進離開，再反向級進回到原音。C 和弦中的 E–F–E，F 是上鄰音。|保留 C 和弦，先彈 E–F–E，再彈 E–D–E。|經過音走向另一個音，鄰音則回到出發音。|tones
84|古典掛留音|Suspensions|掛留音通常先在前一和弦預備，延留到下一和弦形成不協和，再向下級進解決。常見有 4–3 掛留。|在低音 G 上先保持 C，再讓 C 解決到 B，聽四度到三度。|掛留音是一個聲部進行過程，不只是看到 sus4 和弦符號。|tones
85|先現音|Anticipations|先現音比下一個和弦更早出現，並在換和弦後保留或重複，像先透露接下來的和聲。|從 G7 轉到 C 前，讓旋律提早唱 C，再在 C 和弦上保留。|非和弦音的名稱取決於前後文；同一個音可能在下一和弦立刻成為和弦音。|tones
86|持續音|Pedal points|持續音是在和弦改變時，某個聲部保持或重複同一個音。它有時是和弦內音，有時成為和弦外音。|低音固定 C，右手依序彈 C、F、G、C，聽低音維持的中心感。|持續音也能出現在高音聲部，並非只限於低音。|tones
87|模進|Sequences|模進把一段材料搬到不同音高重複。調內模進保留調內音，真實模進則保留精確音程，可能引入變化音。|把 C–D–E 的形狀移成 D–E–F，再比較精確移高全音的 D–E–F♯。|調內模進會保留輪廓，却不一定保留每個半音距離。|omt
88|三段式|Ternary form|基本三段式是 A–B–A：先提出材料，再形成對比，最後回到 A。回歸段可以有裝飾或變化。|寫四小節 A、四小節 B，再回到原先 A，讓兩段有清楚對比。|A–B–A 的三段不必等長，形式辨認不能只靠數小節。|omt
89|移調|Transposition|移調讓所有音移動相同音程，保留旋律與和聲關係。轉給歌手合適的音域時，常需要整首移調。|把 C–F–G–C 整體上移大二度，檢查每個和弦根音與性質。|移調是搬動整段材料；轉調則是音樂進行中改變調性中心。|mt
90|共同和弦轉調|Pivot-chord modulation|共同和弦能同時屬於前後兩個調，先用原調功能理解，再在新調重新解讀，最後建立新主音。|由 C 大調經 Am、D7 到 G；Am 可由 C 的 vi 重新理解為 G 的 ii。|單一外來和弦不一定足以證明轉調，還要看新主音是否持續被建立。|modulation
91|同主音借用|Modal mixture|本課練大調向同主音自然小調借和弦，例如 C 大調借 Fm、A♭、B♭。借用不必立刻改變主音。|在 F–C 前把 F 改為 Fm，聽 A 降到 A♭ 帶來的變化。|C 大調借用的 iv 來自 C 小調，而不是關係小調 A 小調。|mixture
92|三全音替代|Tritone substitution|爵士中可用根音相隔三全音的屬七型和弦替代原屬七，例如 D♭7 代替 G7 解決到 C。|比較 Dm7–G7–Cmaj7 與 Dm7–D♭7–Cmaj7，留意半音下行低音。|G7 的 B、F 與 D♭7 的 C♭、F 在十二平均律中同音，保留了關鍵張力。|sub
93|變化屬和弦|Altered dominants|變化屬和弦常使用 ♭9、♯9、♭5、♯5 等變化音。C altered 音階可由 D♭ 爵士旋律小調的第七級開始理解。|在 G7 上比較 A♭ 與 A♯ 的色彩，再把張力音往 C 和弦內音移動。|♯9 與 ♭3 可同音異名，但在屬和弦中保留大三音時，♯9 的名稱更能表達角色。|jazz
94|拿坡里六和弦|Neapolitan sixth|拿坡里和弦是降二級上的大三和弦，古典常用第一轉位，記作 ♭II6；它通常具有前屬功能。|在 C 小調比較 Ddim/F 與 D♭/F，再接 G–Cm。|名稱中的「六」表示第一轉位，不是把第六音加進和弦。|neapolitan
95|增六和弦|Augmented sixth chords|增六和弦的核心為降六級與升四級，通常反向半音解決到屬音。C 調中 A♭ 向下到 G，F♯ 向上到 G。|先彈 A♭–F♯，再讓兩音分別解決到不同八度的 G。|德國增六和弦可與某個屬七和弦同音異名，但拼法與解決方向不同。|aug6
96|半音三度關係|Chromatic mediants|本課採常見定義：兩個同為大或同為小的三和弦，根音相隔大三度或小三度，且含調外變化，稱半音三度關係。|比較 C→E 與 C→Em。前者需要 G♯，後者是 C 大調內的 iii。|不同教材對半音三度關係的範圍可能略有差異，本課先固定同品質的定義。|omt
97|節拍轉換|Metric modulation|節拍轉換讓前段某個細分或音值的長度，成為後段的新拍長。先算出兩者的時值比例，再推導新 BPM。|舊四分 = 60 時，把舊八分的長度當新四分，新四分就成為 120 BPM。|等號表示兩個音值的實際時間相等，不表示 BPM 的數字也相等。|metric
98|全音音階|Whole-tone scales|全音音階每一步都是全音，一個八度內有六個不同音高。C 起音可用 C、D、E、F♯、G♯、A♯。|彈這六個音再回 C，試著找出為何沒有半音導向的感覺。|十二平均律中，不重複的全音音集合只有兩組，其餘只是換起點。|modes
99|八音減音階|Octatonic diminished scales|八音音階交替全音與半音。爵士常分半全減音階與全半減音階，起始間隔不同，用途也不同。|从 C 彈半、全、半、全的循環，數出回到 C 前的八個音高。|因為小三度對稱，十二平均律中不重複的這類八音集合只有三組。|modes
100|十二音列變形|Twelve-tone rows|十二音列把十二個音級各排列一次。常見變形有移位、倒影、逆行與逆行倒影；本課用 C=0 到 B=11 的模十二運算。|從一條自選音列取前四個數字，試做 T2、I0 與逆行，再用鍵盤驗證。|十二音技法與序列主義不完全同義；節奏、力度等材料也可以被序列化。|row
'''
LEVELS = []
for line in META.strip().splitlines():
    n,title,en,summary,practice,trivia,source = line.strip().split('|')
    n=int(n)
    LEVELS.append(dict(id=n, chapter=(n-1)//10, title=title, english=en, summary=summary.replace('比較','比較').replace('題','題').replace('讓','讓').replace('與','與').replace('却','卻').replace('从','從'), practice=practice.replace('比較','比較').replace('與','與').replace('从','從'), trivia=trivia.replace('却','卻').replace('讓','讓'), sources=[source], questions=[], demo=None))

LETTERS='CDEFGAB'
PCS={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
CHROM=['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B']
ROOTS=['C','D','E','F','G','A','B♭','E♭','A♭','D♭']
DEGREES=['一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五']
def pc(note):
    return (PCS[note[0]]+note.count('♯')-note.count('♭')+2*note.count('𝄪')-2*note.count('𝄫'))%12

def spelled(root,degree,semitones):
    letter=LETTERS[(LETTERS.index(root[0])+degree-1)%7]
    target=(pc(root)+semitones)%12
    delta=(target-PCS[letter]+6)%12-6
    acc={-2:'𝄫',-1:'♭',0:'',1:'♯',2:'𝄪'}
    assert delta in acc,(root,degree,semitones,delta)
    return letter+acc[delta]

def scale(root,offsets):
    return [spelled(root,j+1,k) for j,k in enumerate(offsets)]

def chordspell(root,offsets,degrees=None):
    degrees=degrees or [1,3,5,7][:len(offsets)]
    return '–'.join(spelled(root,d,k) for d,k in zip(degrees,offsets))

def melody(notes,step=.42,duration=None,label='依序聽音高'):
    return {'label':label,'events':[{'at':round(i*step,4),'dur':duration or round(step*.88,4),'notes':[n],'vel':.65} for i,n in enumerate(notes)]}

def harmony(chords,step=1.05,label='依序聽和弦'):
    return {'label':label,'events':[{'at':round(i*step,4),'dur':step*.85,'notes':ns,'vel':.6} for i,ns in enumerate(chords)]}

def rhythm(times,duration=.09,accent=None,label='聽節奏示範'):
    accent=accent or []
    return {'label':label,'events':[{'at':round(t,4),'dur':duration,'notes':[84 if i in accent else 77],'vel':.8 if i in accent else .45} for i,t in enumerate(times)]}

def q(n,p,a,wrong,ex,audio=None,staff=None):
    options=[str(a)]+[str(x) for x in wrong if str(x)!=str(a)]
    options=list(dict.fromkeys(options))
    assert len(options)>=4,(n,p,options)
    d={'id':f'{n:03d}-{len(LEVELS[n-1]["questions"])+1:02d}','prompt':p,'options':options[:4],'correct':0,'explanation':ex}
    if audio:d['audio']=audio
    if staff:d['staff']=staff
    LEVELS[n-1]['questions'].append(d)

def numq(n,p,a,ex,unit=''):
    f=lambda x: f'{x:g}{unit}'
    distract=[x for x in [a+1,a-1,a*2,a/2,a+2,a+3] if x>=0 and x!=a]
    q(n,p,f(a),[f(x) for x in distract],ex)

def manual(n,rows):
    for row in rows.strip().splitlines():
        p,a,b,c,d,ex=row.split('|')
        q(n,p,a,[b,c,d],ex)

def setdemo(n,demo):LEVELS[n-1]['demo']=demo

# Each level below has ten authored or parameterized exercises on its own concept.# 1-10: notation
for i in range(10):
    idx=i%7; direction=1 if i<7 else -1
    a=LETTERS[(idx+direction)%7]
    q(1,f'音名依序往{"上" if direction==1 else "下"}走，{LETTERS[idx]} 的下一個字母是？',a,[x for x in LETTERS if x!=a],f'音名循環為 C–D–E–F–G–A–B–C；{"往上" if direction==1 else "往下"}從 {LETTERS[idx]} 走一步是 {a}。')
for a,b,d in [('C','D',2),('E','F',1),('B','高一個音區的 C',1),('F','G',2),('G','A',2),('A','B',2),('C','E',4),('D','F',3),('F','A',4),('C','下一個 C',12)]:
    numq(2,f'在鍵盤上由 {a} 上行到 {b}，相隔幾個半音？',d,f'把黑鍵也算進去，相鄰琴鍵為一個半音；這段距離共 {d} 個半音。',' 個半音')
manual(3,'''升記號 ♯ 的作用是？|升高半音|降低半音|升高全音|降低全音|♯ 讓原音高升高一個半音。
降記號 ♭ 的作用是？|降低半音|升高半音|降低全音|升高八度|♭ 讓原音高降低一個半音。
C 加上升記號寫成？|C♯|C♭|D♭♭|C♮|升記號放在字母後記為 C♯。
D 加上降記號寫成？|D♭|D♯|E♯|D♮|D 降低半音後是 D♭。
C♯ 遇到還原記號後成為？|C|D|D♯|B♭|還原取消升高，回到 C。
E♭ 遇到還原記號後成為？|E|D|F|E𝄫|還原取消降記號，回到 E。
十二平均律中，E♯ 對應哪個白鍵？|F|E|G|D|E 上方半音是 F，因此 E♯ 與 F 同音。
十二平均律中，C♭ 對應哪個白鍵？|B|C|D|A|C 下方半音是 B，因此 C♭ 與 B 同音。
同一小節、同一八度已有 F♯，後面要改回 F 應標什麼？|還原記號|升記號|降記號|附點|還原記號取消該音的升高變化。
下列哪句正確？|有升記號不一定是黑鍵|升記號一定是黑鍵|還原永遠降半音|降記號會改變音的字母|升降以原音為準；E♯ 與 B♯ 都落在白鍵。''')
for n,clef,notes,steps in [(4,'treble',['C4','E4','F4','G4','A4','B4','C5','D5','E5','F5'],[-2,0,1,2,3,4,5,6,7,8]),(5,'bass',['G2','A2','B2','C3','D3','E3','F3','G3','A3','C4'],[0,1,2,3,4,5,6,7,8,10])]:
    for i,(note,step) in enumerate(zip(notes,steps)):
        q(n,f'讀出譜例 {i+1} 的音名與八度（沒有調號）。',note,[x for x in notes if x!=note],f'從譜表下方往上數線與間，這個位置是 {note}。',staff={'clef':clef,'step':step})
values=[('全音符',4),('二分音符',2),('四分音符',1),('八分音符',.5),('十六分音符',.25)]
for i in range(10):
    name,v=values[i%5]; count=1 if i<5 else 3
    numq(6,f'以四分音符為一拍，{count} 個{name}共幾拍？',v*count,f'{name}是 {v:g} 拍，{count} 個合計 {v*count:g} 拍。',' 拍')
    rest=name.replace('音符','休止符')
    numq(7,f'以四分音符為一拍，連續 {count} 個{rest}要休止幾拍？',v*count,f'休止符與同名音符的時值相同；{count} × {v:g} = {v*count:g} 拍。本題按單個休止符時值計算，非整小節休止記號。',' 拍')
for i,(top,bottom) in enumerate([(2,4),(3,4),(4,4),(2,2),(3,2),(3,8),(5,4),(6,4),(7,4),(4,2)]):
    if i<5:
        numq(8,f'{top}/{bottom} 按下方音符單位計拍，每小節有幾拍？',top,f'上方 {top} 表示每小節有 {top} 個以 {bottom} 分音符為單位的拍。',' 拍')
    else:
        numq(8,f'{top}/{bottom} 的一小節，總長度等於幾個八分音符？',top*8/bottom,f'{top} 個 {bottom} 分音符，各等於 {8/bottom:g} 個八分音符，合計 {top*8/bottom:g} 個。',' 個')
for i in range(10):
    name,v=values[i%5]; double=i>=5; factor=1.75 if double else 1.5
    numq(9,f'以四分音符為一拍，{"雙附點" if double else "附點"}{name}長幾拍？',v*factor,f'原長 {v:g} 拍，乘以 {factor:g}，得到 {v*factor:g} 拍。',' 拍')
manual(10,'''連結線通常連接哪種音？|同音高的音|一定相差八度|一定不同音高|只連接休止符|連結線合併同音高音符的時值。
兩個同音高四分音符以連結線相連，起音幾次？|1 次|2 次|3 次|4 次|只在第一個音符起音，第二個延續聲音。
以四分為一拍，二分與四分音符用連結線相連，共幾拍？|3 拍|1 拍|2 拍|4 拍|二分兩拍加四分一拍，合計三拍。
以四分為一拍，兩個八分音符用連結線相連，共幾拍？|1 拍|0.5 拍|2 拍|1.5 拍|半拍加半拍，合計一拍。
連結線可以跨小節線嗎？|可以，聲音繼續延長|不行，必須重新起音|只能跨休止符|只能用在 3/4|連結線經常用來讓聲音延續到下一小節。
涵蓋 C–D–E 的弧線，通常是？|圓滑線|同音連結線|小節線|反覆記號|不同音高之間的弧線通常表示圓滑或樂句連接。
圓滑線與連結線主要差別是？|前者表達連接奏法，後者合併同音時值|前者降低半音|後者提高八度|兩者必定增加一拍|圓滑線與時值合併是不同層面的記譜功能。
兩個四分音符沒有連結線，也沒有其他延音指示，通常起音幾次？|2 次|1 次|0 次|4 次|各音符分別起音；實際奏法另依樂句與記號決定。
以四分為一拍，附點四分連結八分，共幾拍？|2 拍|1 拍|2.5 拍|3 拍|1.5 加 0.5，總共兩拍。
演奏跨小節連結音時，內心的拍子應如何？|繼續計拍|停止到下一音|重新從零開始|速度加倍|聲音雖持續，節拍與小節結構仍繼續前進。''')

# 11-20: rhythm
for i,(bpm,count) in enumerate([(60,1),(120,1),(80,1),(100,1),(150,1),(60,4),(120,4),(80,4),(100,5),(150,5)]):
    duration=60/bpm*count
    numq(11,f'四分音符 = {bpm} BPM，{count} 個四分音符共幾秒？',duration,f'每拍 60 ÷ {bpm} = {60/bpm:g} 秒，再乘 {count}。',' 秒')
for n,factor,label in [(12,2,'八分音符'),(13,4,'十六分音符'),(14,3,'八分三連音中的音符')]:
    for i in range(10):
        beats=[1,2,3,4,5][i%5]
        if i<5:
            numq(n,f'以四分音符為一拍，{beats} 拍平均細分可容納幾個{label}？',beats*factor,f'每拍分成 {factor} 份；{beats} × {factor} = {beats*factor}。',' 個')
        else:
            count=[2,4,6,8,10][i%5] if n!=14 else [3,6,9,12,15][i%5]
            numq(n,f'以四分音符為一拍，連續 {count} 個{label}總共幾拍？',count/factor,f'每個長 1/{factor} 拍，{count} ÷ {factor} = {count/factor:g} 拍。',' 拍')
manual(15,'''6/8 常見的大拍有幾拍？|2 拍|3 拍|4 拍|6 個四分拍|一般複二拍子 6/8 有兩個附點四分音符大拍。
6/8 每個常見大拍的音值是？|附點四分音符|四分音符|二分音符|十六分音符|一個大拍包含三個八分音符。
6/8 的一大拍通常分成幾個八分音符？|3 個|2 個|4 個|6 個|複拍子的基本拍通常三等分。
6/8 一小節總共等於幾個八分音符？|6 個|3 個|4 個|8 個|拍號記錄每小節六個八分音符的總長度。
6/8 最典型的八分音符分組是？|3+3|2+2+2|4+2 固定不變|1+1+4 固定不變|以兩個大拍理解時，分成三加三。
3/4 與 6/8 的主要差別是？|通常的重音分組不同|一小節總長度必定不同|只能用不同樂器|3/4 沒有八分音符|兩者都可容納六個八分音符，但一個常分 2+2+2，另一個分 3+3。
9/8 依典型複拍子計，有幾個大拍？|3 拍|2 拍|9 個四分拍|4 拍|九個八分音符，每三個構成一個大拍。
12/8 依典型複拍子計，有幾個大拍？|4 拍|3 拍|6 拍|12 個四分拍|十二個八分音符分成四組，每組三個。
6/8 中兩個附點四分音符合計？|一小節|半小節|兩小節|三小節|每個附點四分三個八分，兩個正好六個。
在 6/8 裡，附點四分 = 60 BPM，每個大拍長？|1 秒|0.5 秒|2 秒|3 秒|BPM 的單位指定為附點四分音符，一分鐘六十個就是每個一秒。''')
for i in range(10):
    top=[3,4,2,3,4][i%5]; pickup=[1,1,0.5,0.5,1.5][i%5]
    if i<5:
        numq(16,f'{top}/4 中，弱起只有 {pickup:g} 拍；若與末小節合成完整小節，末小節應有幾拍？',top-pickup,f'以四分音符為一拍，{top} − {pickup:g} = {top-pickup:g}。本題明定首尾合成完整小節。',' 拍')
    else:
        numq(16,f'{top}/4 的弱起從小節最後 {pickup:g} 拍開始，要再經過幾拍才到下一個第一拍？',pickup,f'這段弱起剩餘長度就是 {pickup:g} 拍；演奏時節拍持續前進。',' 拍')
manual(17,'''切分音常把注意力放在哪裡？|原本較弱的節拍位置|只放在第一拍|只放在最後一小節|只放在最高音|切分使弱位置凸顯，與原有的拍感形成偏移。
腳踩正拍，手只拍 and，屬於哪種練習？|反拍與切分感練習|升降記號練習|八度轉位|移調練習|把手放在正拍之間，可以練習偏移感。
弱拍起音後用連結線跨過強拍，可能形成？|切分|調號改變|全音音階|音高必升高|跨過強拍的延音會改變聽見的重音期待。
演奏切分時，底拍應如何？|保持穩定|跟每個重音重新開始|遇休止就停|永遠加快|底拍是比較基準，不能被切分帶走。
4/4 中每拍分成「數字、and」，and 位於？|兩個正拍之間|每小節最前面|正拍前整整兩拍|每個正拍同一時間|以四分拍為基準，and 是半拍位置。
下列哪個現象本身不足以判定切分？|旋律音高變高|弱拍被強調|弱起延到強拍|強拍休止、弱拍起音|音高與節奏重音是不同面向。
切分一定要使用連結線嗎？|不一定|一定要|只限兩條連結線|只能用圓滑線|重音、休止與起音位置也能形成切分。
切分與失去拍子的差別是？|切分仍能對準穩定底拍|切分完全沒有拍子|切分只能自由速度|两者沒有差別|切分是有意識的節奏安排，不是隨意偏離時間。
要練弱拍重音，較適合先做哪件事？|先穩定數出細分|先把速度開到最快|先取消所有節拍參考|先只背和弦名稱|知道每個細分位置，才能準確放置弱拍重音。
同一節奏移動半拍後，可能改變？|與强弱拍的關係|音名一定改變|樂器一定改變|所有音值一定加倍|切分感與材料落在拍子的哪個位置有關。''')
manual(18,'''Swing 八分音符的入門描述是？|一對音前長後短|每個音等長|前短後長固定 1:3|所有音都變十六分|常以前長後短來理解 Swing 的成對八分音符。
入門以三連音近似 Swing，前一音佔幾份？|2 份|1 份|3 份|4 份|把一拍分三份，前音約佔兩份，後音一份。
Swing 的比例是否永遠 2:1？|不是，隨速度與風格改變|是，任何速度都一樣|永遠 1:1|永遠 4:1|2:1 是方便入門的近似，不是所有演奏的固定法則。
Straight eighths 指的是？|平均八分音符|前長後短八分音符|所有音都連結|只有休止符|Straight 表示一對八分通常均分拍長。
附點八分加十六分的比例是？|3:1|2:1|1:1|1:2|附點八分相當於三個十六分，後音一個。
把 Swing 直接當成附點八分加十六分，問題在於？|把彈性的律動固定成 3:1|音高會消失|拍號必變 3/4|無法使用鋼琴|Swing 不應一律被僵化為 3:1。
Swing 改變成對八分的長短時，整拍總長通常？|仍維持原拍長|一定加倍|一定減半|完全無法計拍|長短比例改變，並不自動改變整體 BPM。
用 90 BPM 比較 straight 與 swing，應保持什麼相同？|基本拍速|所有八分音符都等長|和弦一定相同才有拍子|每次起音都在正拍|先固定底拍，才能比較細分比例。
練習 Swing 時，最可靠的補充方式是？|聆聽具體風格的演奏|只背一個永久比例|把所有弱拍刪掉|只調高音量|Swing 有風格與演奏細節，數學近似不能完全取代聆聽。
哪一句較準確？|Swing 是律動處理，不是另一種音階|Swing 一定改變調號|Swing 就是快速演奏|Swing 只能出現在 3/4|本關讨论的是時間分配與重音，不是音高集合。''')
for i,group in enumerate(['2+3','3+2','2+2+3','3+2+2','2+3+2','3+3+2','2+3+3','3+2+3','2+2+2+3','3+2+2+2']):
    parts=list(map(int,group.split('+')))
    if i<5:numq(19,f'以八分音符為一格，分組 {group} 合計對應幾個八分音符？',sum(parts),f'{group} = {sum(parts)}，可容納於 {sum(parts)}/8 的一小節。',' 個')
    else:numq(19,f'以八分音符為一格，分組 {group} 中有幾組三連格（長度為 3 的組）？',parts.count(3),f'逐組查看 {group}，其中有 {parts.count(3)} 組長度為三。這裡是分組，不是三連音記號。',' 組')
manual(20,'''3:2 複節奏的意思是？|同一段時間一邊三下、一邊兩下|三拍後停止兩拍|音量比例三比二|三個音高配兩個調號|兩個聲部共享同一段總長度，各自平均分三與分二。
用最小共同格點表示 3:2，適合分幾格？|6 格|5 格|4 格|3 格|3 與 2 的最小公倍數是 6。
六格中，三下平均起音的位置是？|第 1、3、5 格|第 1、2、3 格|第 2、3、4 格|第 1、4、6 格|每隔兩格起音一次。
六格中，兩下平均起音的位置是？|第 1、4 格|第 1、2 格|第 2、6 格|第 3、4 格|每隔三格起音一次。
一輪 3:2 若共長 2 秒，兩下聲部相鄰起音間隔？|1 秒|0.5 秒|2 秒|3 秒|兩下平均分配在兩秒的週期，間隔一秒。
一輪 3:2 若共長 3 秒，三下聲部相鄰起音間隔？|1 秒|1.5 秒|0.5 秒|3 秒|三下平均分配在三秒的週期，間隔一秒。
兩邊同時開始後，下一次週期邊界在哪裡？|三下和兩下都完成一輪後|第一邊打第二下時必定重合|每個起音都重合|永遠不重合|完整週期結束，兩邊會再次一起起音。
3:2 中各聲部自己的節奏可以是？|各自平均|一邊一定隨機|兩邊都無法數拍|一邊一定忽快忽慢|交錯來自分割方式不同，不必靠不均勻演奏。
先練 3:2 時，哪個方法較直接？|先畫六格標示兩手起音|先取消共同時間|只增加音量|只變更音高|共同格點把兩個週期對齊。
複節奏與輪流演奏的差別是？|複節奏讓不同分割同時存在|複節奏一定沒有同時聲部|輪流演奏一定是 3:2|兩者完全相同|本關重點是同時疊置，而不是先三下再兩下。''')

# 21-30: intervals
for i,(root,degree) in enumerate(zip(ROOTS,[3,5,4,6,2,7,8,6,3,6])):
    upper=LETTERS[(LETTERS.index(root[0])+degree-1)%7]
    q(21,f'只數字母，{root[0]} 上行到{"下一個 " if degree==8 else ""}{upper} 是幾度？',DEGREES[degree-1]+'度',[DEGREES[j-1]+'度' for j in [2,3,4,5,6,7,8] if j!=degree],f'起點和終點都算，依序數 {degree} 個字母位置，所以是{DEGREES[degree-1]}度。')
interval_sets={22:[(2,1,'小二度'),(2,2,'大二度')],23:[(3,3,'小三度'),(3,4,'大三度')],24:[(4,5,'完全四度'),(5,7,'完全五度')],25:[(6,8,'小六度'),(6,9,'大六度'),(7,10,'小七度'),(7,11,'大七度')]}
allnames=['小二度','大二度','小三度','大三度','完全四度','增四度','完全五度','小六度','大六度','小七度','大七度','完全八度']
for n,types in interval_sets.items():
    for i,root in enumerate(ROOTS):
        d,s,name=types[i%len(types)]; upper=spelled(root,d,s)
        if i<6:q(n,f'{root} 上行到 {upper}（不超過八度），正確音程是？',name,[x for x in allnames if x!=name],f'字母相距 {d} 度，音高距離 {s} 個半音，因此是{name}。')
        else:q(n,f'{root} 上方的{name}，正確音名是？',upper,[x for x in CHROM if pc(x)!=pc(upper)],f'从 {root} 數到第 {d} 個字母，並核對 {s} 個半音，得到 {upper}。')
for simple in [2,3,4,5,6]:
    numq(26,f'一個八度加一個{DEGREES[simple-1]}度，合成幾度？',simple+7,f'度數相加須減一：8 + {simple} − 1 = {simple+7}。','度')
for degree in [9,10,11,12,15]:
    numq(26,f'{degree} 度去掉一個八度，剩幾度？',degree-7,f'移除八度時減七個度數：{degree} − 7 = {degree-7}。','度')
for root,d,s,name in [('C',4,6,'增四度'),('C',5,6,'減五度'),('D',4,6,'增四度'),('G',5,6,'減五度'),('C',2,3,'增二度'),('F',5,8,'增五度'),('A',3,2,'減三度'),('D',7,9,'減七度'),('F',4,6,'增四度'),('G',2,3,'增二度')]:
    upper=spelled(root,d,s)
    q(27,f'{root} 上行到 {upper}，依正確拼法屬於？',name,[x for x in ['增四度','減五度','增二度','增五度','減三度','減七度','小三度','大二度'] if x!=name],f'先數出 {d} 度，再核對 {s} 個半音；拼法決定它是{name}。')
for a,b in [('大二度','小七度'),('小三度','大六度'),('完全四度','完全五度'),('完全五度','完全四度'),('大六度','小三度'),('小七度','大二度'),('增四度','減五度'),('減五度','增四度'),('完全八度','完全一度'),('大三度','小六度')]:
    q(28,f'{a}轉位後成為？',b,[x for x in allnames+['完全一度'] if x!=b],f'轉位度數相加為九，大與小互換、增與減互換、完全不變。因此{a}變為{b}。')
for a,b in [('C♯','D♭'),('D♯','E♭'),('F♯','G♭'),('G♯','A♭'),('A♯','B♭'),('E♯','F'),('B♯','C'),('C♭','B'),('F♭','E'),('F𝄪','G')]:
    q(29,f'十二平均律中，{a} 與哪個音同音異名？',b,[x for x in CHROM if pc(x)!=pc(b)],f'{a} 與 {b} 對應相同琴鍵，但字母與升降拼法不同。')
for i,(s,name) in enumerate([(1,'小二度'),(2,'大二度'),(3,'小三度'),(4,'大三度'),(5,'完全四度'),(7,'完全五度'),(8,'小六度'),(9,'大六度'),(10,'小七度'),(12,'完全八度')]):
    root=57+(i%5)
    q(30,f'聽力題 {i+1}：兩個音形成哪一種上行音程？',name,[x for x in allnames if x!=name],f'兩音相隔 {s} 個半音，因此是{name}。可重播並試著唱回兩個音。',audio=melody([root,root+s],.9,.75,'播放兩個音'))

# 31-40: keys and scales
MAJOR=[0,2,4,5,7,9,11]; MINOR=[0,2,3,5,7,8,10]
for i,root in enumerate(ROOTS):
    degree=[3,7,4,6,7,3,4,6,2,7][i]
    a=scale(root,MAJOR)[degree-1]
    q(31,f'{root} 大調的第 {degree} 級音是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{root} 大調：'+ '–'.join(scale(root,MAJOR))+f'。第 {degree} 級是 {a}。')
circle=['C','G','D','A','E','B','F♯','C♯','G♯','D♯','A♯']
for i in range(10):
    a=circle[i+1]
    q(32,f'沿五度圈向上五度的方向，{circle[i]} 之後是？',a,[x for x in circle if x!=a],f'由 {circle[i]} 上行完全五度到 {a}。進入較多升號時也可以改用同音異名的調名。')
for n,keys,acc in [(33,['G','D','A','E','B','F♯','C♯'],['F♯','C♯','G♯','D♯','A♯','E♯','B♯']),(34,['F','B♭','E♭','A♭','D♭','G♭','C♭'],['B♭','E♭','A♭','D♭','G♭','C♭','F♭'])]:
    for i,key in enumerate(keys):
        numq(n,f'{key} 大調的調號有幾個{"升" if n==33 else "降"}號？',i+1,f'{key} 大調使用：'+ '、'.join(acc[:i+1])+'。',' 個')
    for i in [1,3,5]:
        q(n,f'依加入順序，第 {i+1} 個{"升" if n==33 else "降"}號是？',acc[i],[x for x in acc if x!=acc[i]],'順序為：'+'、'.join(acc)+'。')
for i,root in enumerate(ROOTS):
    degree=[3,6,7,2,6,7,3,6,4,7][i]; a=scale(root,MINOR)[degree-1]
    q(35,f'{root} 自然小調的第 {degree} 級音是？',a,[x for x in CHROM if pc(x)!=pc(a)],'自然小調依序為：'+'–'.join(scale(root,MINOR))+f'；第 {degree} 級是 {a}。')
    relative=scale(root,MAJOR)[5]
    q(36,f'{root} 大調的關係小調是？',relative+' 小調',[x+' 小調' for x in ROOTS if pc(x)!=pc(relative)],f'大調第六級 {relative} 是關係小調的主音，兩調共用調號。')
    if i<5:
        q(37,f'{root} 大調的同主音小調是？',root+' 小調',[x+' 小調' for x in ROOTS if pc(x)!=pc(root)],f'同主音的主音保持 {root}，只改變大小調性質；與關係大小調不同。')
    else:
        d=[3,6,7,3,6][i-5]; a=scale(root,MINOR)[d-1]
        q(37,f'由 {root} 大調改成同主音自然小調，第 {d} 級變為？',a,[x for x in CHROM if pc(x)!=pc(a)],f'自然小調相對同主音大調降低第 3、6、7 級；此處第 {d} 級是 {a}。')
    seventh=spelled(root,7,11)
    q(38,f'{root} 和聲小調的第七級音是？',seventh,[x for x in CHROM if pc(x)!=pc(seventh)],f'自然小調第七級提高半音，成為距主音上方十一個半音的 {seventh}。')
manual(39,'''古典教材中，A 旋律小調上行的第六級是？|F♯|F|G|G♯|上行升高第六、七級，A 小調第六級 F 升為 F♯。
古典教材中，A 旋律小調上行的第七級是？|G♯|G|F♯|A♯|上行第七級升高為 G♯。
古典慣例的 A 旋律小調下行，常用哪組六、七級？|F、G|F♯、G♯|F、G♯|F♯、G|下行常回到自然小調，因此用 F 與 G。
爵士 A 旋律小調通常上下行都使用？|F♯、G♯|F、G|F、G♯|F♯、G|爵士語境通常保留升六、升七的形式。
C 爵士旋律小調的第三級是？|E♭|E|D|F|旋律小調仍有小三度，C 的第三級是 E♭。
C 爵士旋律小調的第六級是？|A|A♭|B♭|G|旋律小調第六級相對主音為大六度，故為 A。
D 爵士旋律小調的第七級是？|C♯|C|B♭|D♯|D 上方大七度是 C♯。
旋律小調相對自然小調，上行通常改變哪兩級？|第六、七級|第二、三級|第四、五級|第一、二級|古典上行與爵士形式都升高第六與第七級。
和聲小調與爵士旋律小調主要差在哪一級？|第六級|第一級|第三級|第五級|兩者都有升七級，旋律小調再升高第六級。
看見「旋律小調下行」題目，首先要確認什麼？|古典或爵士語境|樂器品牌|譜紙顏色|錄音音量|兩種語境對下行的慣例不同，不能省略條件。''')
solfege=['do','re','mi','fa','sol','la','ti']
for i,root in enumerate(ROOTS):
    d=[1,3,5,2,4,6,7,3,5,2][i]; a=scale(root,MAJOR)[d-1]
    q(40,f'採大調首調唱名，{root} 大調的 {solfege[d-1]} 是哪個音？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{root} 為 do；{solfege[d-1]} 是第 {d} 級，所以是 {a}。')

# 41-50: triads and inversions
TRIADS=[('大三和弦','',[0,4,7]),('小三和弦','m',[0,3,7]),('減三和弦','dim',[0,3,6]),('增三和弦','aug',[0,4,8])]
for n,(name,symbol,offsets) in zip([41,42,43,44],TRIADS):
    for i,root in enumerate(ROOTS):
        a=chordspell(root,offsets)
        others=[chordspell(root,o) for _,_,o in TRIADS if o!=offsets]
        q(n,f'{root}{symbol}（{root} {name}）的正確組成音是？',a,others,f'{name}相對根音的半音位置是 '+ '、'.join(map(str,offsets))+f'，因此是 {a}。')
for i,root in enumerate(ROOTS):
    is4=i%2==0; d=4 if is4 else 2; s=5 if is4 else 2
    a=chordspell(root,[0,s,7],[1,d,5]); other=chordspell(root,[0,2 if is4 else 5,7],[1,2 if is4 else 4,5])
    q(45,f'{root}sus{d} 的基本組成音是？',a,[chordspell(root,[0,4,7]),chordspell(root,[0,3,7]),other],f'sus{d} 以第 {d} 級取代三音；根音、{d} 音與五音為 {a}。')
    a=chordspell(root,[0,7],[1,5])
    q(46,f'{root}5 五度和弦不加八度時，哪兩個音是核心？',a,[chordspell(root,[0,4],[1,3]),chordspell(root,[0,3],[1,3]),chordspell(root,[0,6],[1,5])],f'五度和弦以根音與完全五度為核心：{a}；因為沒有三音，不直接指定大小。')
    a=chordspell(root,[0,4,7,14],[1,3,5,9])
    q(47,f'{root}add9 的組成音是？',a,[chordspell(root,[0,4,7,10]),chordspell(root,[0,4,7,11]),chordspell(root,[0,2,7],[1,2,5])],f'add9 在大三和弦上加九音，保留三音，且不自動加入七音：{a}。')
    for n,d,s in [(48,3,4),(49,5,7)]:
        a=spelled(root,d,s)
        q(n,f'{root} 大三和弦的第{"一" if n==48 else "二"}轉位，最低音應是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'第{"一" if n==48 else "二"}轉位以{"三" if n==48 else "五"}音為低音，{root} 的這個和弦音是 {a}；根音仍為 {root}。')
    bass=spelled(root,3,4) if i<5 else CHROM[(pc(root)+10)%12]
    q(50,f'和弦符號 {root}/{bass} 指定的最低音是？',bass,[x for x in CHROM if pc(x)!=pc(bass)],f'斜線左側 {root} 是和弦，右側 {bass} 是指定低音。這個低音不一定屬於左側三和弦。')# 51-60: functional harmony
roman=['I','ii','iii','IV','V','vi','vii°']; qualities=['大三和弦','小三和弦','小三和弦','大三和弦','大三和弦','小三和弦','減三和弦']; suffix=['','m','m','','','m','dim']
def diatonic(root,d):return scale(root,MAJOR)[d-1]+suffix[d-1]
def progression(root,ds):return ' → '.join(diatonic(root,d) for d in ds)
for i,root in enumerate(ROOTS):
    d=[1,2,3,4,5,6,7,2,6,7][i];a=qualities[d-1]
    q(51,f'{root} 大調只用調內音，在第 {d} 級疊出的三和弦性質是？',a,[x for x in ['大三和弦','小三和弦','減三和弦','增三和弦'] if x!=a],f'大調各級依序是大、小、小、大、大、小、減；第 {d} 級的 {diatonic(root,d)} 是{a}。')
    chord=diatonic(root,d)
    q(52,f'在 {root} 大調，{chord} 應標成哪個羅馬數字？',roman[d-1],[x for x in roman if x!=roman[d-1]],f'{chord} 建立在第 {d} 級，依性質使用 {roman[d-1]}。')
manual(53,'''基本 I–IV–V–I 中，第一個 I 的功能是？|主功能|屬功能|前屬功能|與調性無關|I 建立主音與調性中心。
基本 I–IV–V–I 中，IV 常擔任？|前屬功能|主音本身|十二音列|音符休止|IV 常引導音樂走向屬和弦。
基本 I–IV–V–I 中，V 常擔任？|屬功能|單純音量變化|拍號功能|固定主功能|V 在這個語境中傾向解決到 I。
C 大調的 C–F–G–C，哪個是屬和弦？|G|C|F|Dm|G 是 C 大調第五級上的大三和弦。
G 大調的 G–C–D–G，哪個是前屬位置？|C|G|D|F♯dim|C 是 IV，在此位於 I 與 V 之間。
D 大調的 I 是？|D|A|G|Em|主和弦建立在主音 D 上。
常見功能順序是哪一個？|主 → 前屬 → 屬 → 主|前屬 → 主 → 前屬 → 前屬一定不變|屬 → 屬 → 屬就是所有音樂|任何和弦都沒有上下文|本關的基本模型為 T–PD–D–T，並非所有風格唯一的規則。
在 C 大調，Dm–G–C 可理解為？|前屬 → 屬 → 主|屬 → 主 → 前屬|主 → 主 → 主|三個不同拍號|ii 常擔任前屬功能，V 為屬，I 為主。
判斷一個和弦的功能，還需要看什麼？|調性與前後進行|只有音量|只有樂器顏色|只有演奏人數|功能是和弦在具體調性語境中的角色。
把「小和弦一定悲傷」當成和聲功能，問題是？|把情緒印象與功能混為一談|所有小和弦都沒有音高|小和弦不可能有節奏|功能只看速度|情緒受到多種因素影響，功能則談和弦在調性中的作用。''')
manual(54,'''完全正格終止的核心進行是？|V（或 V7）→ I|IV → I|I → V|V → vi|完全正格終止以屬到主為核心。
完全正格終止中，最後 I 的最高聲部需落在哪級？|第 1 級|第 3 級|第 5 級|第 7 級|古典 PAC 的最後最高聲部要落主音。
完全正格終止中，V 與 I 的低音位置通常需？|兩者皆根音位置|兩者都第一轉位|兩者都第二轉位|任意轉位都算完全|根音位置是此類終止的判準之一。
C 大調完全正格終止的低音可為？|G → C|F → C|C → G|G → A|屬根音 G 接主根音 C。
G 大調完全正格終止最後的最高音應為？|G|B|D|F♯|最高聲部最後落 G，才能符合此判準。
D 大調的 V → I 是？|A → D|G → D|D → A|A → Bm|D 大調的屬根音是 A，主根音是 D。
只有 V → I，就一定是完全正格終止嗎？|不一定，還要檢查位置與最高聲部|一定是|只有慢歌才是|要看鼓的數量|要符合根音位置與最後旋律主音等條件。
C 大調 G → C，但最後最高音為 E，可否只憑此判為 PAC？|不符合 PAC 的最高聲部條件|完全符合|一定是半終止|一定是變格終止|最後是三音 E，不是主音 C，因此不是完全正格終止。
F 大調的 PAC 最後低音是？|F|C|B♭|D|主和弦必須在根音位置，所以最低音為 F。
辨認終止前，應先確認這段是否？|位於樂句結束處|至少用了十個音|必定很大聲|完全沒有休止|終止描述樂句的收束，不能把所有相鄰和弦都直接當終止。''')
for i,root in enumerate(ROOTS):
    dom=diatonic(root,5)
    q(55,f'{root} 大調樂句若形成基本半終止，句尾停在哪個和弦？',dom,[diatonic(root,j) for j in [1,2,4,6] if diatonic(root,j)!=dom],f'半終止停在 V；{root} 大調的 V 是 {dom}。')
    for n,ds in [(56,[4,1]),(57,[5,6]),(58,[1,5,6,4])]:
        a=progression(root,ds)
        alternates=[[5,1],[1,4],[2,5],[4,1],[5,6],[1,4,6,5],[6,4,1,5],[1,6,4,5]]
        wrong=[progression(root,x) for x in alternates if x!=ds and len(x)==len(ds)]
        title={56:'基本變格終止 IV–I',57:'常見阻礙終止 V–vi',58:'I–V–vi–IV 進行'}[n]
        q(n,f'{root} 大調的{title}是？',a,wrong,f'逐級換成實際和弦：{a}。注意第六級用小三和弦。' if n!=56 else f'IV 是 {diatonic(root,4)}，I 是 {root}，形成 {a}。')
    sc=scale(root,MAJOR)
    a=f'{sc[1]}m7 → {sc[4]}7 → {root}maj7'
    q(59,f'{root} 大調的 ii7–V7–Imaj7 是？',a,[f'{sc[1]}7 → {sc[4]}m7 → {root}maj7',f'{sc[3]}maj7 → {sc[4]}m7 → {root}m7',f'{sc[5]}m7 → {sc[1]}m7 → {sc[4]}7'],f'第二級是小七、第五級是屬七、第一級是大七：{a}。')
manual(60,'''由 C–E–G 到 C–F–A，哪個音可以原地保留？|C|E|G|B|兩個和弦共有 C，E→F、G→A 可就近移動。
C 大三和弦與 Am 共有哪兩個音？|C、E|C、G|E、G|A、G|C–E–G 與 A–C–E 的共同音為 C、E。
C 大三和弦與 G 大三和弦的共同音是？|G|C|E|F|C–E–G 與 G–B–D 只共有 G。
G7 解決到 C 時，B 常傾向移向？|C|F|G♯|E♭|B 是 C 大調導音，常上行半音到 C。
G7 解決到 C 時，七音 F 常傾向移向？|E|F♯|A♭|B|古典基本解決中，和弦七音向下級進到 E。
要讓 C–E–G 換到 Am 少移動，可選哪個配置？|C–E–A|A–C–E 全部跳低八度|A–E–C 全部大跳|所有聲部任意換位|保留 C 與 E，讓 G 上移到 A，能減少位移。
聲部進行關心的是？|每條聲部怎樣連接前後音|只有和弦名稱長短|只有節拍器外觀|只有主旋律的音量|把各個聲部當成旋律，觀察其移動與彼此關係。
「就近移動」是否是所有音樂唯一的正確方式？|不是，是本課練習原則|是，任何跳進都錯|只有鼓能例外|用了轉位就不能移動|風格與編曲可能需要跳進或改變音域。
C–E–G 到 B–D–G，可原地保留？|G|C|E|F|後一組為 G 和弦第一轉位，共同音 G 可保持。
同一個和弦換轉位，最可能改變什麼？|低音與聲部線條|所有音的字母必改變|調號必定增加|節拍單位必定改變|和弦性質可不變，但低音與各聲部位置會改變。''')

# 61-70: seventh chords
SEVENTHS=[('大七和弦','maj7',[0,4,7,11]),('屬七和弦','7',[0,4,7,10]),('小七和弦','m7',[0,3,7,10]),('半減七和弦','m7♭5',[0,3,6,10]),('全減七和弦','dim7',[0,3,6,9]),('小大七和弦','m(maj7)',[0,3,7,11])]
for n,(name,symbol,offsets) in zip(range(61,67),SEVENTHS):
    for root in ROOTS:
        a=chordspell(root,offsets)
        wrong=[chordspell(root,o) for _,_,o in SEVENTHS if o!=offsets]
        q(n,f'{root}{symbol} 的正確四個和弦音是？',a,wrong,f'{name}從根音計算的半音位置為 '+ '、'.join(map(str,offsets))+f'，按根、三、五、七音拼為 {a}。')
for i,root in enumerate(ROOTS):
    inversion=i%3+1; d=[3,5,7][inversion-1];s=[4,7,11][inversion-1];a=spelled(root,d,s)
    q(67,f'{root}maj7 的第{DEGREES[inversion-1]}轉位，最低音是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'七和弦第{DEGREES[inversion-1]}轉位以第 {d} 和弦音為低音，因此是 {a}。')
    degree=[9,11,13,9,11,13,9,11,13,9][i];semi={9:14,11:17,13:21}[degree];a=spelled(root,degree,semi)
    q(68,f'以 {root} 為根音，未升降的第 {degree} 延伸音是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{degree} 度相當於第 {degree-7} 級提高八度；{root} 的這個音是 {a}。')
    name,sym,offsets=SEVENTHS[i%3];a='、'.join([spelled(root,3,offsets[1]),spelled(root,7,offsets[3])])
    wrong=['、'.join([spelled(root,1,0),spelled(root,5,offsets[2])]),'、'.join([spelled(root,1,0),spelled(root,3,offsets[1])]),'、'.join([spelled(root,5,offsets[2]),spelled(root,7,offsets[3])])]
    q(69,f'{root}{sym} 的三音與七音（導引音）是哪一組？',a,wrong,f'先按 {name} 的結構找三音與七音：{a}。')
    targetdegree=[5,2,6,4,5,2,6,4,5,2][i];goal=scale(root,MAJOR)[targetdegree-1];sec=spelled(goal,5,7)
    q(70,f'在 {root} 大調，要用副屬七和弦導向第 {targetdegree} 級的 {diatonic(root,targetdegree)}，應用哪個和弦？',sec+'7',[x+'7' for x in ROOTS if pc(x)!=pc(sec)],f'先把 {goal} 當暫時主音，它上方完全五度是 {sec}，因此用 {sec}7 導向它。')

# 71-80: modes and pentatonic / blues collections
MODES=[('Ionian',[0,2,4,5,7,9,11],'1 2 3 4 5 6 7','不改變任何級數','C'),('Dorian',[0,2,3,5,7,9,10],'1 2 ♭3 4 5 6 ♭7','降低第 3、7 級','D'),('Phrygian',[0,1,3,5,7,8,10],'1 ♭2 ♭3 4 5 ♭6 ♭7','降低第 2、3、6、7 級','E'),('Lydian',[0,2,4,6,7,9,11],'1 2 3 ♯4 5 6 7','升高第 4 級','F'),('Mixolydian',[0,2,4,5,7,9,10],'1 2 3 4 5 6 ♭7','降低第 7 級','G'),('Aeolian',[0,2,3,5,7,8,10],'1 2 ♭3 4 5 ♭6 ♭7','降低第 3、6、7 級','A'),('Locrian',[0,1,3,5,6,8,10],'1 ♭2 ♭3 4 ♭5 ♭6 ♭7','降低第 2、3、5、6、7 級','B')]
for n,(mode,offs,formula,changes,white) in zip(range(71,78),MODES):
    for i,root in enumerate(ROOTS[:6]):
        degree=[2,3,4,5,6,7][i];a=scale(root,offs)[degree-1]
        q(n,f'{root} {mode} 的第 {degree} 級音是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{mode} 的公式是 {formula}，因此 {root} 的第 {degree} 級為 {a}。')
    q(n,f'{mode} 相對主音的正確級數公式是？',formula,[x[2] for x in MODES if x[0]!=mode],f'{mode} 使用 {formula}；請從主音確認每個音程。')
    steps=[offs[i+1]-offs[i] for i in range(6)]+[12-offs[-1]]
    pattern='–'.join('全' if x==2 else '半' for x in steps)
    otherpatterns=[]
    for m,o,_,_,_ in MODES:
        if m==mode:continue
        ds=[o[i+1]-o[i] for i in range(6)]+[12-o[-1]]
        otherpatterns.append('–'.join('全' if x==2 else '半' for x in ds))
    q(n,f'{mode} 相鄰音至八度的距離依序是？',pattern,otherpatterns,f'由公式逐步相減，得到 {pattern}。')
    q(n,f'只使用白鍵，並確實建立哪個音為中心，可形成 {mode}？',white,[x for x in LETTERS if x!=white],f'以 {white} 為中心使用白鍵，音程排列符合 {mode}；仍須透過樂句與和聲建立中心。')
    q(n,f'{mode} 與同主音大調相比，改變了什麼？',changes,[x[3] for x in MODES if x[0]!=mode],f'比較兩個級數公式，{mode} 需要{changes}。')
for n,offsets,degs,name in [(78,[0,2,4,7,9],[1,2,3,5,6],'大調五聲音階'),(79,[0,3,5,7,10],[1,3,4,5,7],'小調五聲音階'),(80,[0,3,5,6,7,10],[1,3,4,5,5,7],'小調藍調音階')]:
    for root in ROOTS:
        a=chordspell(root,offsets,degs)
        alternatives=[]
        for changed in [1,2,3]:
            other=offsets[:];other[changed]+=1
            alternatives.append('–'.join(CHROM[(pc(root)+x)%12] for x in other))
        q(n,f'從 {root} 開始，哪一組符合{name}？',a,alternatives,f'依本課公式從 {root} 取音，得到 {a}。排列按上行音高，不重複列八度。')

# 81-90: writing and form
manual(81,'''動機通常指？|可辨認的短小音樂材料|只能是一整首歌|固定一百個音|只指和弦的根音|短小的節奏或音高關係就能成為動機。
保留節奏、把所有音提高同一音程，屬於？|動機移位|完全刪除動機|只改變音量|加上休止的同義詞|移位保留音程關係，換到另一個音高位置。
把動機每個時值乘二，稱為？|增值|減值|逆行|換樂器而已|增值拉長節奏比例，例如八分變四分。
把動機每個時值減半，稱為？|減值|增值|調號還原|附點|減值使同樣的节奏比例更緊湊。
一個四分、兩個八分的動機增值兩倍，變成？|一個二分、兩個四分|一個八分、兩個十六分|三個全音符|三個等長八分|所有時值都乘二，長短關係保留。
C–D–E 移高全音，成為？|D–E–F♯|D–E–F|C–E–G|E–D–C|精確移高兩個半音，保留原來的全音接全音。
把 C–D–E 的順序倒過來，是？|E–D–C|C–E–G|D–E–F|C–C–C|逆行反轉音符的先後順序。
辨認動機時，哪個也可能是重要線索？|節奏輪廓|只有音量大小|只有檔案名稱|只能看最後音|節奏常能讓材料在換音高後仍被認出。
動機重複時改變配器，原動機可能？|仍然可辨認|必定消失|必定轉調|必定變成休止|配器變了，但節奏與音程特徵仍可保留。
發展動機的實作方式何者最具體？|保留節奏，只改最後一個音|每次完全隨機無關|只能重複同一段錄音|把所有音都刪除|有限度改變讓聽者同時感到熟悉與變化。''')
for i,root in enumerate(ROOTS):
    sc=scale(root,MAJOR)
    if i<5:pattern=f'{sc[0]}–{sc[1]}–{sc[2]}';a=sc[1]
    else:pattern=f'{sc[2]}–{sc[3]}–{sc[4]}';a=sc[3]
    q(82,f'在 {root} 大三和弦上彈 {pattern}，哪個音是級進連接兩個和弦音的經過音？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{a} 位於兩個和弦音之間，前後同方向級進，符合經過音的型態。')
    neighbor=sc[3] if i%2==0 else sc[1]
    q(83,f'在 {root} 大三和弦上彈 {sc[2]}–{neighbor}–{sc[2]}，哪個音是鄰音？',neighbor,[x for x in CHROM if pc(x)!=pc(neighbor)],f'由和弦音 {sc[2]} 級進到 {neighbor}，再回到 {sc[2]}，中間音是鄰音。')
manual(84,'''古典掛留音的典型三步是？|預備 → 掛留 → 解決|休止 → 轉調 → 加速|移調 → 移調 → 移調|附點 → 重音 → 升號|先預備同一音，再在和弦改變時形成不協和，最後級進解決。
4–3 掛留的數字相對於？|當時的低音|全曲速度|音量大小|歌手數量|4 與 3 表示該聲部相對低音的音程。
低音 G 上的 C→B 是哪種典型掛留解決？|4–3|7–6|9–8|2–1|C 在 G 上方為四度，B 為三度。
典型 suspension 的解決方向通常是？|向下級進|必定向上八度|任意大跳才算|完全不移動|古典掛留通常向下級進；向上解決另有 retardation 等區分。
掛留音通常在哪種位置形成張力？|相對較強的位置|永遠只能最弱位置|只能無拍音樂|只能在休止期間|在和弦改變後的較強位置形成不協和，再解決。
低音 C 上 D→C，若符合預備與掛留，是？|9–8 掛留|4–3 掛留|7–6 掛留|旋律移調|D 位於高八度附近時可理解為九度，解決到八度 C。
看到 Csus4，能否立即認定有完整古典掛留過程？|不能，還要看聲部前後|能，完全不用看|只能在吉他判定|只要大聲就算|流行和弦符號指定組成，未必交代預備與解決。
掛留音的「預備」通常表示？|同一音先在前一和弦中出現|先把音量調大|先換成另一個調|一定先空一拍|前一和弦先出現該音，之後延留產生張力。
掛留音的「解決」主要觀察？|不協和音如何移到較穩定的和弦音|檔案是否存檔|樂器是否停止|BPM 是否歸零|這是聲部與和聲之間的相對移動。
7–6 掛留中，上方聲部通常移動多少字母位置？|向下級進一級|向上五度|向下八度|完全不動|由低音上方七度降到六度，是向下級進。''')
manual(85,'''先現音的特徵是？|下一和弦的音提前出現|前一和弦音延後才解決|所有音都加倍|只出現在最前一小節|先現音在和聲改變前就透露下一和弦。
G7→C 前，旋律提早唱 C 並保留，C 可理解為？|先現音|只憑此就是經過音|必定是低音持續音|三連音|C 提前成為下一個 C 和弦的和弦音。
先現音常見在哪種位置？|換和弦前的較弱位置|永遠只在第一拍|一定無拍|只在休止符內|它常在較弱位置預告下一和弦。
先現音與掛留音的時間方向有何差別？|先現提早，掛留延後|兩者都只表示快兩倍|兩者都只表示低音|完全沒有區別|先現借下一和弦的音，掛留保留前一和弦的音。
F→C 前，提早唱 E 並在 C 上保留，E 可是？|先現音|轉調記號|反覆記號|休止符|E 不屬 F 三和弦，卻屬即將到來的 C 三和弦。
C→G 前，提早唱 B 並保留，B 與下一和弦關係是？|G 和弦的三音|G 和弦的根音|G 和弦的五音|G 和弦的小七音|G–B–D 中，B 是三音。
D7→G 前，提早唱 G 並保留，G 與下一和弦關係是？|根音|大三音|五音|小七音|下一個 G 和弦以 G 為根音。
判斷先現音不能只看什麼？|單獨一個音名|下一和弦|出現時間|是否保留或重複|沒有前後和聲與節奏，就無法分類。
先現音進入下一和弦後，通常變成？|和弦內音|必定永遠不協和|休止|升高兩個八度|它原先就是下一和弦的成員。
寫作先現音時，最直接的做法是？|讓目標和弦音提前半拍|把所有音推遲兩小節|只刪去低音|任意更改拍號|先選下一和弦的音，再安排它較早進入。''')
manual(86,'''持續音的核心概念是？|和聲改變時仍保留同一音|所有和弦永遠不變|所有音都越來越高|只能演休止|背景和聲變化，某聲部仍保持或重複一個音。
低音 C 固定、上方 C→F→G→C，可形成？|持續音|十二音列必然完成|全部同一和弦|音程轉位必定發生|固定的 C 貫穿不同和聲。
持續音一定只能在低音嗎？|不一定，也能在其他聲部|一定只能最低音|只能鼓演奏|只能無調性音樂|高音或內聲部也可以形成持續音。
持續音在各和弦中可能？|有時是和弦音、有時不是|永遠必須是每個和弦根音|永遠都是三音|必定每拍移動|其與上方和聲的關係會隨和弦改變。
固定 G 低音配 C 大三和弦時，G 是？|五音|根音|三音|七音|C–E–G 的 G 是五音。
固定 C 低音配 F 大三和弦時，C 是？|五音|根音|三音|七音|F–A–C 的 C 是五音。
固定 C 低音配 G 大三和弦時，C 是？|該三和弦之外的音|根音|三音|五音|G–B–D 不含 C，因此固定 C 與此和聲產生額外張力。
持續音可以重複起音，而不是一次拉長嗎？|可以|不可以|只能兩次|只能一次半|持續音概念可包含反覆同一音的情況。
選擇主音當持續低音，可能有什麼作用？|維持調性中心感|必定轉到遠系調|使拍號消失|使所有旋律同音|不變的主音可讓其他變化圍繞同一個中心。
持續音與「整個和弦不換」最大的差別是？|前者允許其他聲部與和聲改變|前者不能有聲音|後者一定是複節奏|兩者完全相同|持續的是某一音，而非必須凍結所有材料。''')
for i in range(5):
    shift=i+1; notes=[0,2,4];target=[x+shift for x in notes]
    a='–'.join(CHROM[x%12] for x in target)
    q(87,f'C–D–E 做真實模進，精確上移 {shift} 個半音，音高依序是？',a,['–'.join(CHROM[(x+k)%12] for x in notes) for k in [0,6,7,8] if k!=shift],f'每個音都加 {shift} 個半音，保留原有的全音距離，得到 {a}。本題允許同音異名。')
for i in range(5):
    start=i+1;seq=LETTERS[start:start+3] if start+3<=7 else ''.join(LETTERS[(start+j)%7] for j in range(3));a='–'.join(seq)
    others=['C–E–G','C–D–E','F–A–C','G–B–D']
    q(87,f'C 大調中，把 C–D–E 的連續三級輪廓移到 {LETTERS[start]} 開始，調內模進為？',a,[x for x in others if x!=a],f'只用 C 大調音，從 {LETTERS[start]} 依序取三個級進音，得到 {a}。半音分布不必與原句完全一樣。')
manual(88,'''基本三段式的結構是？|A–B–A|A–B|A–B–C–D|A–B–A–C–A|先提出 A、再對比 B，最後返回 A。
三段式中 B 段的常見角色是？|提供對比|必須與 A 完全相同|一定只能休止|一定只有一個音|對比能讓 A 的回歸更清楚。
A–B–A′ 中的 A′ 通常表示？|A 的變化回歸|全新無關的第四段|必定轉為 7/8|A 被完全刪除|撇號常表示保有原材料但做了變化。
三段式的三段一定等長嗎？|不一定|一定每段四小節|一定每段十小節|只能三個音|形式靠材料與結構辨認，不只看小節數。
辨認 A 回歸最有用的線索是？|原先主題或材料重新出現|音量一定最大|一定換鼓手|必定同一錄音時間|旋律、節奏、和聲或織度可提供回歸線索。
只有 A–B，尚未回歸 A，比較接近？|二段式的基本輪廓|完整三段式|必定十二音列|必定迴旋曲|基本二段式有兩個主要部分；仍需看完整音樂語境。
A–B–A–C–A 比基本 ABA 多了什麼？|另一次對比段與回歸|完全沒有 A|只有兩段|每段都必須移調|這是常見迴旋輪廓，與基本三段式不同。
設計三段式，哪個順序最直接？|提出主題、對比、回歸|每段完全無關且不回來|只把同一音拉長|只變更檔名|三段式的可辨識結構來自 A 的回歸。
回歸 A 時增加裝飾音，是否必定失去三段式？|不會，仍可為 A′|一定會|只能算全新 B|一定變四段式|裝飾不一定改變材料的基本身分。
判斷樂曲形式時，較合理的方式是？|聽材料關係與段落邊界|只看歌曲總秒數|只看樂器數量|只看 BPM 高低|形式來自音樂材料如何組織與回歸。''')
for i,root in enumerate(ROOTS):
    target=ROOTS[(i+1)%len(ROOTS)];a=progression(target,[1,6,4,5]);src=progression(root,[1,6,4,5])
    q(89,f'把 {root} 大調的「{src}」整體移到 {target} 大調，應成為？',a,[progression(target,p) for p in [[1,5,6,4],[1,4,2,5],[6,4,1,5]]],f'先保留 I–vi–IV–V 的級數與大小性質，再套入 {target} 大調：{a}。')
for chord,k1,r1,k2,r2 in [('Am','C','vi','G','ii'),('Em','C','iii','G','vi'),('C','C','I','G','IV'),('Dm','C','ii','F','vi'),('Am','C','vi','F','iii'),('F','C','IV','F','I'),('Bm','G','iii','D','vi'),('Em','G','vi','D','ii'),('G','G','I','D','IV'),('C','F','V','C','I')]:
    a=f'{k1} 的 {r1} → {k2} 的 {r2}'
    q(90,f'以 {chord} 作為 {k1} 大調轉向 {k2} 大調的共同和弦，它的雙重角色是？',a,[f'{k1} 的 V → {k2} 的 V',f'{k1} 的 ii → {k2} 的 IV',f'{k1} 的 IV → {k2} 的 iii'],f'{chord} 同時屬於兩調，可由 {r1} 重新解讀為 {r2}。仍需要後續進行建立新調。')

# 91-100: advanced topics
for i,root in enumerate(ROOTS):
    d=[4,6,7,4,6,7,4,6,7,4][i];sc=scale(root,MINOR);a=sc[d-1]+('m' if d==4 else '')
    q(91,f'{root} 大調向同主音自然小調借用 {"iv" if d==4 else "♭VI" if d==6 else "♭VII"}，實際和弦是？',a,[diatonic(root,j) for j in [1,2,3,4,5,6] if diatonic(root,j)!=a],f'在 {root} 自然小調，第 {d} 級根音為 {sc[d-1]}，相應借用和弦是 {a}。')
flatnames=['C','D♭','D','E♭','E','F','G♭','G','A♭','A','B♭','B']
for root in ['G','C','D','A','E','B','F♯','D♭','A♭','E♭']:
    sub=flatnames[(pc(root)+6)%12]
    q(92,f'{root}7 的三全音替代屬七和弦是？',sub+'7',[x+'7' for x in flatnames if pc(x)!=pc(sub)],f'兩個根音相隔六個半音，因此用 {sub}7 替代 {root}7；導引音有同音異名的對應。')
for i,root in enumerate(ROOTS):
    d,s,label=[(9,13,'♭9'),(9,15,'♯9'),(5,6,'♭5'),(5,8,'♯5')][i%4];a=spelled(root,d,s)
    q(93,f'{root}7 和弦的 {label} 變化音，依正確拼法是？',a,[x for x in CHROM if pc(x)!=pc(a)],f'{label} 相對根音是 {s} 個半音，且維持第 {d} 度的字母，因此是 {a}。')
    neap=spelled(root,2,1);bass=spelled(neap,3,4);a=f'{neap}/{bass}'
    q(94,f'{root} 小調的拿坡里六和弦（♭II6），用斜線和弦表示是？',a,[f'{root}/{spelled(root,3,3)}',f'{spelled(root,5,7)}7/{spelled(root,7,11)}',f'{spelled(root,4,5)}m/{root}'],f'降二級 {neap} 建立大三和弦，再將三音 {bass} 放在低音，得到 {a}。')
manual(95,'''增六和弦的核心兩音相對調主音是？|降六級與升四級|第一級與第五級|第二級與第三級|降二級與第五級|核心增六度位於 ♭6 與 ♯4 之間。
C 調中，核心增六度可拼為？|A♭–F♯|A♭–G♭|A–F|C–G|A♭ 是降六級，F♯ 是升四級，字母相距六度。
C 調的 A♭ 與 F♯ 通常如何解決？|A♭ 下行至 G，F♯ 上行至 G|兩音都下行全音|兩音都保持|A♭ 到 C，F♯ 到 E♭ 必定如此|兩個音反向半音移動到不同八度的屬音 G。
義大利增六和弦除了 ♭6 與 ♯4，包含？|第 1 級|第 2 級與 ♭3|第 5 級與第 7 級|只有第 7 級|義大利型的核心組成為 ♭6、1、♯4。
法國增六和弦比義大利型再加入？|第 2 級|降第 7 級|升第 1 級|第 5 級|法國型為 ♭6、1、2、♯4。
德國增六和弦比義大利型再加入？|降第 3 級|第 2 級|升第 5 級|第 7 級|德國型為 ♭6、1、♭3、♯4。
C 調的義大利增六和弦是？|A♭–C–F♯|A–C–F|A♭–C–G|A–C♯–G|按 ♭6、1、♯4 取音，得到 A♭、C、F♯。
C 調的法國增六和弦是？|A♭–C–D–F♯|A♭–C–E♭–F♯|A–C–D–F|G–B–D–F|法國型包含第 2 級 D。
C 調的德國增六和弦是？|A♭–C–E♭–F♯|A♭–C–D–F♯|A–C–E–G|G–B–D–F|德國型包含降第 3 級 E♭。
古典增六和弦一般屬於哪種功能？|前屬功能|固定主功能|只有打擊功能|與解決方向無關|它通常強烈導向屬和弦，必要時先經終止六四配置。''')
for i,root in enumerate(ROOTS):
    semis=4 if i%2==0 else 3;quality='' if i<5 else 'm';target=spelled(root,3,semis);a=target+quality
    wrong=[spelled(root,d,s)+quality for d,s in [(2,2),(4,5),(5,7)]]
    q(96,f'採本課「同品質、根音三度關係」定義，哪個和弦與 {root}{quality} 構成半音三度關係？',a,wrong,f'兩者同為{"大" if quality=="" else "小"}三和弦，根音 {root}–{target} 相隔{"大" if semis==4 else "小"}三度，且含原調外的變化。')
for bpm,factor,label in [(60,2,'舊八分 = 新四分'),(80,2,'舊八分 = 新四分'),(100,2,'舊八分 = 新四分'),(90,2/3,'舊附點四分 = 新四分'),(120,2/3,'舊附點四分 = 新四分'),(150,2/3,'舊附點四分 = 新四分'),(60,3,'舊八分三連音的一個音 = 新四分'),(80,3,'舊八分三連音的一個音 = 新四分'),(60,1.5,'舊四分三連音的一個音 = 新四分'),(80,1.5,'舊四分三連音的一個音 = 新四分')]:
    result=round(bpm*factor,6)
    numq(97,f'舊四分 = {bpm} BPM，若「{label}」，新的四分 BPM 是多少？',result,f'新拍的每分鐘數為舊 BPM × {factor:g}，所以 {bpm} × {factor:g} = {result:g}。',' BPM')
for i,root in enumerate(ROOTS):
    offs=[0,2,4,6,8,10];a='–'.join(CHROM[(pc(root)+o)%12] for o in offs)
    wrong=['–'.join(CHROM[(pc(root)+o)%12] for o in other) for other in [[0,2,4,5,7,9],[0,1,3,5,7,9],[0,2,3,6,8,10]]]
    q(98,f'從 {root} 出發，哪組琴鍵音高符合全音音階（不重複八度）？',a,wrong,f'每一步兩個半音，因此得到 {a}。本題接受以同音異名表示琴鍵。')
    half=i%2==0;offs=[0,1,3,4,6,7,9,10] if half else [0,2,3,5,6,8,9,11];a='–'.join(CHROM[(pc(root)+o)%12] for o in offs)
    wrong=['–'.join(CHROM[(pc(root)+o)%12] for o in other) for other in ([[0,2,3,5,6,8,9,11],[0,1,3,5,6,7,9,10],[0,1,2,4,6,7,9,10]] if half else [[0,1,3,4,6,7,9,10],[0,2,4,5,6,8,9,11],[0,2,3,5,7,8,9,11]])]
    q(99,f'從 {root} 出發，哪組琴鍵音高符合{"半全" if half else "全半"}減音階？',a,wrong,f'以{"半、全" if half else "全、半"}交替，到八度前共有八個不同音高：{a}。')
row=[0,2,1,5]
for op,param in [('T',2),('T',5),('T',7),('I',0),('I',4),('I',7),('R',0),('RI',0)]:
    if op=='T':ans=[(x+param)%12 for x in row];rule=f'每個數加 {param}，再取模 12'
    elif op=='I':ans=[(param-x)%12 for x in row];rule=f'每個數 x 變成 ({param}−x) mod 12'
    elif op=='R':ans=row[::-1];rule='將原片段的先後順序反轉'
    else:ans=[(-x)%12 for x in row][::-1];rule='先做 I0，再把順序反轉'
    a=' '.join(map(str,ans));label=op+str(param) if op in ['T','I'] else op
    alternatives=[' '.join(str((x+k)%12) for x in ans) for k in [1,2,3]]
    q(100,f'音列片段 [0, 2, 1, 5] 做 {label}，結果為？（C=0）',a,alternatives,f'{rule}，得到 [{a}]。此處 R 只反轉題目給定的片段；RI 採 I0 後逆行。')
manual(100,'''標準十二音列包含多少個不同音級？|12 個|7 個|8 個|24 個|一條標準音列把十二個音級各排列一次；音級不區分八度。
下列哪一列包含十二個不同音級、沒有重複？|0 2 1 5 4 8 6 11 7 3 10 9|0 2 1 5 4 8 6 11 7 3 10 0|0 2 1 5 4 8 6 11 7 3 10 10|0 2 1 5 4 8 6 11 7 3 10 11|第一列完整使用 0 至 11 各一次，其餘有重複並遺漏某個音級。''')# Original synthesized demonstrations. MIDI numbers use C4 = 60.
setdemo(1,melody([60,62,64,65,67,69,71,72],label='C–D–E–F–G–A–B–C'))
setdemo(2,melody([64,65,71,72],.65,label='E–F，B–C：白鍵之間的半音'))
setdemo(3,melody([60,61,60,62,61,62],.6,label='C–C♯–C，再聽 D–D♭–D'))
setdemo(4,melody([64,67,71,74,77],label='高音譜表五條線：E4–G4–B4–D5–F5'))
setdemo(5,melody([43,47,50,53,57],label='低音譜表五條線：G2–B2–D3–F3–A3'))
t=0;ev=[]
for beats in [4,2,1,.5,.25]:ev.append({'at':t,'dur':beats*.5*.94,'notes':[60],'vel':.6});t+=beats*.5
setdemo(6,{'label':'四分 = 120：全、二分、四分、八分、十六分','events':ev})
setdemo(7,rhythm([0,1,2,3],label='每次發聲後留一個四分休止；底拍為 120'))
setdemo(8,rhythm([i*.5 for i in range(6)],accent=[0,3],label='3/4：兩個小節，每小節三拍'))
setdemo(9,rhythm([0,.75,1,1.75,2,2.75],accent=[0,2,4],label='附點四分加八分：長 1.5 拍，短 0.5 拍'))
setdemo(10,{'label':'先聽兩次 C 起音，再聽一次連結長音','events':[{'at':0,'dur':.45,'notes':[60],'vel':.6},{'at':.5,'dur':.45,'notes':[60],'vel':.6},{'at':1.5,'dur':1,'notes':[60],'vel':.6}]})
setdemo(11,rhythm([0,1,2,3.5,4,4.5,5],label='先聽 60 BPM，再聽 120 BPM'))
setdemo(12,rhythm([i*.3 for i in range(8)],accent=[0,2,4,6],label='四分拍 100 BPM；每拍兩個八分細分'))
setdemo(13,rhythm([i*.15 for i in range(16)],accent=[0,4,8,12],label='四分拍 100 BPM；每拍四個十六分細分'))
setdemo(14,rhythm([0,.3,.6,.9,1.8,2,2.2,2.4,2.6,2.8],label='同一拍速：先二等分，再三等分'))
setdemo(15,rhythm([i*.25 for i in range(6)]+[2+i*.25 for i in range(6)],accent=[0,3,6,8,10],label='先 6/8 的 3+3，再 3/4 的 2+2+2'))
setdemo(16,rhythm([0,.25,.75,1.25,1.75,2.25],accent=[1,5],label='一個八分弱起，接到下一小節的第一拍'))
setdemo(17,rhythm([.25,.75,1.25,1.75,2.25,2.75],label='只在每拍 and 起音；四分底拍為 120'))
setdemo(18,rhythm([0,.3,.6,.9,1.8,2.2,2.4,2.8],label='先平均八分，再示範近似 2:1 的 Swing'))
setdemo(19,rhythm([i*.25 for i in range(14)],accent=[0,2,4,7,9,11],label='7/8：2+2+3，聽分組的第一下'))
ev=[]
for r in range(2):
    for t in [0,.4,.8]:ev.append({'at':r*1.2+t,'dur':.1,'notes':[84],'vel':.55})
    for t in [0,.6]:ev.append({'at':r*1.2+t,'dur':.12,'notes':[60],'vel':.7})
setdemo(20,{'label':'高音三下，低音兩下，共享同一個週期','events':ev})
for n,notes,label in [(21,[60,64,60,67],'C–E 是三度，C–G 是五度'),(22,[60,61,60,62],'小二度，再大二度'),(23,[60,63,60,64],'小三度，再大三度'),(24,[60,65,60,67],'完全四度，再完全五度'),(25,[60,70,60,71],'小七度，再大七度'),(26,[60,62,60,74],'大二度，再大九度'),(27,[60,65,60,66],'完全四度，再增四度'),(28,[60,64,64,72],'大三度轉位成小六度'),(29,[61,61],'C♯ 與 D♭：同一個琴鍵'),(30,[60,67,62,69],'不同起音，同樣是上行完全五度')]:
    setdemo(n,melody(notes,.7,.58,label))
setdemo(31,melody([60+x for x in MAJOR+[12]],label='C 大調音階'))
setdemo(32,melody([60,67,62,69,64,71,66],.6,label='五度圈根音 C–G–D–A–E–B–F♯（部分移低八度）'))
setdemo(33,melody([62+x for x in MAJOR+[12]],label='D 大調：聽見 F♯ 與 C♯'))
setdemo(34,melody([63+x for x in MAJOR+[12]],label='E♭ 大調：三個降號'))
setdemo(35,melody([57+x for x in MINOR+[12]],label='A 自然小調'))
setdemo(36,harmony([[48,60,64,67],[45,60,64,69]],label='C 大調與關係 A 小調的主和弦'))
setdemo(37,harmony([[48,60,64,67],[48,60,63,67]],label='同主音 C 大三和弦與 C 小三和弦'))
setdemo(38,harmony([[45,60,64],[52,59,67],[45,60,64],[45,60,64],[52,59,68],[45,60,64]],.85,'Am–Em–Am，再 Am–E–Am'))
setdemo(39,melody([57,59,60,62,64,66,68,69,67,65,64,62,60,59,57],.3,label='古典 A 旋律小調：上行升六七，下行自然小調'))
setdemo(40,melody([60,64,67,67,71,74],.55,label='C 大調與 G 大調的 do–mi–sol'))
for n,(_,_,offs) in zip(range(41,45),TRIADS):setdemo(n,harmony([[60+x for x in offs]],1.8,label='C '+TRIADS[n-41][0]))
setdemo(45,harmony([[60,65,67],[60,64,67]],label='Csus4 → C'))
setdemo(46,harmony([[48,55,60],[53,60,65],[55,62,67]],label='C5 → F5 → G5'))
setdemo(47,harmony([[48,60,64,67],[48,60,64,67,74]],label='C → Cadd9'))
setdemo(48,harmony([[48,60,64,67],[52,60,64,67]],label='C 根音位置 → C/E 第一轉位'))
setdemo(49,harmony([[48,60,64,67],[55,60,64,67]],label='C 根音位置 → C/G 第二轉位'))
setdemo(50,harmony([[48,60,64,67],[47,60,64,67],[45,60,64,69]],label='C → C/B → Am，留意低音 C–B–A'))
setdemo(51,harmony([[60,64,67],[62,65,69],[64,67,71],[65,69,72],[67,71,74],[69,72,76],[71,74,77]],.65,label='C 大調的七個順階三和弦'))
setdemo(52,harmony([[48,60,64,67],[45,60,64,69],[41,60,65,69],[43,59,62,67]],label='C 大調 I–vi–IV–V'))
setdemo(53,harmony([[48,60,64,67],[41,60,65,69],[43,59,62,67],[48,60,64,67]],label='C 大調：主 → 前屬 → 屬 → 主'))
setdemo(54,harmony([[43,62,65,71],[48,60,64,72]],1.4,label='G7 → C，最高聲部 B→C、低音 G→C'))
setdemo(55,harmony([[48,60,64,67],[41,60,65,69],[43,59,62,67]],label='C–F–G，停在屬和弦'))
setdemo(56,harmony([[41,60,65,69],[48,60,64,67]],1.4,label='F → C：變格終止'))
setdemo(57,harmony([[43,59,62,65],[45,60,64,69]],1.4,label='G7 → Am：阻礙式收束'))
setdemo(58,harmony([[48,60,64,67],[43,59,62,67],[45,60,64,69],[41,60,65,69]],label='C–G–Am–F'))
setdemo(59,harmony([[50,60,65,69],[43,59,65,69],[48,59,64,67]],label='Dm7–G7–Cmaj7'))
setdemo(60,harmony([[60,64,67],[60,65,69],[59,62,67],[60,64,67]],label='共同音保留，其他聲部就近移動'))
for n,(_,_,offs) in zip(range(61,67),SEVENTHS):setdemo(n,harmony([[48]+[60+x for x in offs]],1.8,label='C '+SEVENTHS[n-61][0]))
setdemo(67,harmony([[48,60,64,67,71],[52,60,64,67,71],[55,60,64,67,71],[59,60,64,67,71]],label='Cmaj7：根音、第一、第二、第三轉位'))
setdemo(68,harmony([[48,64,67,70],[48,64,67,70,74]],label='C7 → C9，加入九音 D'))
setdemo(69,harmony([[65,72],[65,71],[64,71]],label='只聽導引音：F–C，F–B，E–B'))
setdemo(70,harmony([[48,60,64,67],[50,60,66,69],[43,59,62,67]],label='C → D7 → G：副屬和弦導向 G'))
for n,(mode,offs,_,_,_) in zip(range(71,78),MODES):setdemo(n,melody([60+x for x in offs+[12]],label='同一主音 C 的 '+mode+' 調式'))
setdemo(78,melody([60,62,64,67,69,72],label='C 大調五聲音階'))
setdemo(79,melody([57,60,62,64,67,69],label='A 小調五聲音階'))
setdemo(80,melody([60,63,65,66,67,70,72],label='C 小調藍調音階，留意 F–G♭–G'))
setdemo(81,{'label':'同一個 C–D–E 動機，後半時值加倍','events':[{'at':t,'dur':d,'notes':[m],'vel':.6} for t,d,m in [(0,.25,60),(.3,.25,62),(.6,.5,64),(1.5,.5,60),(2.1,.5,62),(2.7,1,64)]]})
for n,notes,label in [(82,[72,74,76,76,74,72],'C 和弦上的 C–D–E 與 E–D–C，D 為經過音'),(83,[76,77,76,76,74,76],'E–F–E 與 E–D–E：上鄰音與下鄰音')]:
    d=melody(notes,.45,label=label);d['events'].append({'at':0,'dur':2.7,'notes':[48,55,64],'vel':.23});setdemo(n,d)
setdemo(84,{'label':'低音轉至 G 時保留 C，再由 C 解決至 B','events':[{'at':0,'dur':.95,'notes':[48,64,67],'vel':.4},{'at':0,'dur':2,'notes':[72],'vel':.6},{'at':1,'dur':2,'notes':[43,55,62],'vel':.4},{'at':2,'dur':.9,'notes':[71],'vel':.6}]})
setdemo(85,{'label':'G7 → C 前，旋律 C 提前出現','events':[{'at':0,'dur':1.45,'notes':[43,59,62,65],'vel':.4},{'at':1.2,'dur':1.3,'notes':[72],'vel':.7},{'at':1.5,'dur':1.2,'notes':[48,60,64,67],'vel':.4}]})
d=harmony([[60,64,67],[60,65,69],[59,62,67],[60,64,67]],1,label='持續低音 C，上方 C–F–G–C');d['events'].append({'at':0,'dur':4,'notes':[36],'vel':.6});setdemo(86,d)
setdemo(87,melody([60,62,64,62,64,65,64,65,67],.35,label='C 大調內模進：C–D–E，D–E–F，E–F–G'))
setdemo(88,melody([60,64,67,60,62,65,69,62,60,64,67,60],.38,label='原創短句 A–B–A，聽材料回歸'))
setdemo(89,harmony([[48,60,64,67],[41,60,65,69],[43,59,62,67],[48,60,64,67],[50,62,66,69],[43,62,67,71],[45,61,64,69],[50,62,66,69]],.8,label='I–IV–V–I：先 C 大調，再移至 D 大調'))
setdemo(90,harmony([[48,60,64,67],[45,60,64,69],[50,60,66,69],[43,59,62,67]],label='C–Am–D7–G；Am 由 vi 重新理解為 ii'))
setdemo(91,harmony([[48,60,64,67],[41,60,65,69],[41,60,65,68],[48,60,64,67]],label='C–F–Fm–C：借用同主音小調 iv'))
setdemo(92,harmony([[50,60,65,69],[43,59,65,69],[48,59,64,67],[50,60,65,69],[49,59,65,68],[48,59,64,67]],.85,label='先 ii–V–I，再 ii–♭II7–I'))
setdemo(93,harmony([[43,59,62,65,68],[48,60,64,67]],1.4,label='G7♭9 → C，A♭ 解決到 G'))
setdemo(94,harmony([[48,60,63,67],[41,61,65,68],[43,59,62,67],[48,60,63,67]],label='Cm → D♭/F → G → Cm'))
setdemo(95,harmony([[56,60,66],[55,59,67]],1.5,label='C 調義大利增六和弦解決到 G'))
setdemo(96,harmony([[48,60,64,67],[52,59,64,68],[56,60,63,68],[48,60,64,67]],label='大三和弦 C–E–A♭–C：根音三度移動'))
setdemo(97,rhythm([0,1,2,3,4,4.5,5,5.5,6,6.5,7],label='四分 60 → 四分 120：舊八分成為新四分'))
setdemo(98,melody([60,62,64,66,68,70,72],label='C 全音音階'))
setdemo(99,melody([60,61,63,64,66,67,69,70,72],label='C 半全減音階'))
setdemo(100,melody([60+x for x in [0,2,1,5,4,8,6,11,7,3,10,9]],.34,label='原創十二音列：十二個音級各一次'))

# Final content normalization, structure checks and exports.
traditional=str.maketrans({'讓':'讓','與':'與','為':'為','題':'題','从':'從','两':'兩','强':'強','變':'變','节':'節','动':'動','论':'論','会':'會','过':'過','连':'連','这':'這','听':'聽','并':'並','后':'後','对':'對','個':'個'})
def normalize(obj):
    if isinstance(obj,str):return obj.translate(traditional)
    if isinstance(obj,list):return [normalize(x) for x in obj]
    if isinstance(obj,dict):return {k:normalize(v) for k,v in obj.items()}
    return obj
LEVELS=normalize(LEVELS)
assert len(LEVELS)==100
seen=set()
for lesson in LEVELS:
    assert len(lesson['questions'])==10,(lesson['id'],len(lesson['questions']))
    assert len(set(q['prompt'] for q in lesson['questions']))==10,lesson['id']
    assert lesson['demo'] and lesson['demo']['events'],lesson['id']
    assert lesson['sources'][0] in SOURCES
    # A source/interactive resource is available in every lesson, without auto-embedding trackers.
    lesson['videoQuery']=lesson['english']+' music theory lesson'
    lesson['example']={'prompt':lesson['questions'][0]['prompt'],'answer':lesson['questions'][0]['options'][0],'explanation':lesson['questions'][0]['explanation']}
    for item in lesson['questions']:
        assert item['id'] not in seen;seen.add(item['id'])
        assert len(item['options'])==4 and len(set(item['options']))==4,item
        assert len(item['explanation'])>=5,item
        assert 0<=item['correct']<4
        for demo in [item.get('audio')]:
            if demo:
                assert all(0<=e['at'] and 0<e['dur']<10 and all(20<=x<=100 for x in e['notes']) for e in demo['events'])
    assert all(0<=e['at'] and e['dur']>0 and all(20<=x<=100 for x in e['notes']) for e in lesson['demo']['events']),lesson['id']
DATA={'version':'1.0.0','checked':'2026-10-02','scope':'以西方十二平均律及常見樂理為主；古典與爵士慣例依題目標示。這是自編學習路線，不對應任何官方檢定級數。','chapters':[{'id':i,'title':t,'description':d,'english':en} for i,(t,d,en) in enumerate(CHAPTERS)],'sources':SOURCES,'levels':LEVELS}
content=json.dumps(DATA,ensure_ascii=False,separators=(',',':'))
DATA['contentHash']=hashlib.sha256(content.encode()).hexdigest()[:12]
(ROOT/'src'/'curriculum.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'src'/'curriculum.js').write_text('window.ARCO_DATA='+json.dumps(DATA,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
outline=['# ARCO v1.0｜100 級課程\n',DATA['scope']+'\n','每級 10 題，正式模式需答對至少 8 題。題目、講解與合成音示範皆為本版自編。\n']
for chapter in DATA['chapters']:
    outline.append(f'## {chapter["id"]+1}. {chapter["title"]}\n')
    for lesson in LEVELS[chapter['id']*10:chapter['id']*10+10]:
        outline.append(f'### 第 {lesson["id"]} 級｜{lesson["title"]}\n{lesson["summary"]}\n\n實作：{lesson["practice"]}\n\n冷知識：{lesson["trivia"]}\n')
(ROOT/'docs'/'CURRICULUM.md').write_text('\n'.join(outline),encoding='utf-8')
print(f'Built {len(LEVELS)} levels, {len(seen)} questions, {sum(1 for l in LEVELS if l["demo"])} demos; hash {DATA["contentHash"]}')