"""Generate the human-readable curriculum from the same data as the website."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'src/curriculum.json').read_text(encoding='utf-8'))
lines = ['# ARCO v2.1.0｜100 級課程', '', data['scope'], '',
    '每級 10 題，正式模式需答對至少 8 題。每級有一個互動實作及一組三步演奏任務；互動判定與演奏自評是不同紀錄。', '',
    '以下教材、情境與題目為自編；參考資料供延伸理解，未宣稱逐段摘自單一來源。此路線不對應官方檢定。', '']
for chapter in data['chapters']:
    lines += [f"## {chapter['id']+1}. {chapter['title']}", '', chapter['description'], '']
    for lesson in [x for x in data['levels'] if x['chapter'] == chapter['id']]:
        lines += [f"### 第 {lesson['id']} 級｜{lesson['title']}", '', lesson['summary'], '',
                  '#### 理解與推導', '', *[p+'\n' for p in lesson['understand']],
                  '**推導示例**：'+lesson['worked'], '', '**容易誤會的地方**：'+lesson['trap'], '',
                  '#### 動手做一次', '', lesson['workshop']['prompt'], '',
                  '#### 帶進演奏', '', '**情境**：'+lesson['mission']['scene'], '',
                  '**目標**：'+lesson['mission']['goal'], '']
        lines += [f"{i+1}. {text}" for i,text in enumerate(lesson['mission']['steps'])]
        lines += ['', '**自我檢查**：'+lesson['mission']['check'], '',
                  '**冷知識**：'+lesson['trivia'], '',
                  '**題目安排**：2 題觀念確認、4 題推算與辨讀、2 題情境應用、2 題分析與整合。', '']
        for source in lesson['sources']:
            entry = data['sources'][source]
            lines += [f"參考教材：[{entry['title']}]({entry['url']})", '']
(ROOT / 'docs/CURRICULUM.md').write_text('\n'.join(lines), encoding='utf-8')
print('Built curriculum document: 100 enriched lessons')