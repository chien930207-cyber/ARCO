// Deterministic, dependency-free placement engine regression tests.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const {webcrypto} = require('node:crypto');
const root=path.resolve(__dirname,'..');
const D=JSON.parse(fs.readFileSync(path.join(root,'src/curriculum.json'),'utf8'));
const Q=new Map(D.levels.flatMap(l=>l.questions.map(q=>[q.id,{...q,level:l.id}])));
let S, saves=0, seed=9127;
const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const shuffle=arr=>{const a=[...arr];for(let i=a.length-1;i>0;i--){let j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const stub={open:false,focus(){},close(){},showModal(){},addEventListener(){}};
const c={console,crypto:webcrypto,confirm:()=>true,setTimeout:()=>0,location:{hash:'#home'},document:{querySelector:()=>stub,addEventListener(){}},scrollTo(){}};
c.window=c;
c.ARCO={D,Q,escape:s=>String(s),icon:()=>'',brandMark:()=>'',getState:()=>S,save:()=>saves++,shuffle,stopAudio(){},notify(){},lesson:n=>D.levels[n-1],setContent(){},audioCard:()=>'',staffView:()=>'',go:route=>{c.location.hash='#'+route;if(route==='placement')c.ArcoPlacement.render();}};
vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(root,'src/placement.js'),'utf8'),c);
const P=c.ArcoPlacement;
const reset=()=>{S={onboardingSeen:false,placement:null,placementSeen:[],best:{},testBest:{},testMode:false};};
const snapshot=()=>JSON.parse(JSON.stringify(P.getRun()));
function take(scores){P.start();for(let i=0;i<15;i++){let q=P.current(),correct=i%3<scores[Math.floor(i/3)];P.answer(correct?q.correct:-1);P.next();}return snapshot();}
const checks=[];
const ok=s=>{checks.push(s);console.log('PASS',s);};
reset();
for(let i=0;i<1000;i++){
 const qs=P.sample();assert.equal(qs.length,15);assert.equal(new Set(qs.map(q=>q.id)).size,15);assert.equal(new Set(qs.map(q=>q.prompt.normalize('NFKC').replace(/\s+/g,''))).size,15);
 for(let j=0;j<5;j++){let t=qs.filter(q=>q.tier===j);assert.equal(t.length,3);assert(t.every(q=>q.level>=j*20+1&&q.level<=(j+1)*20));assert.equal(t[0].difficulty,1);assert.equal(t[1].difficulty,2);assert(t[2].difficulty>=3);}
 for(const q of qs){assert.deepEqual([...q.order].sort(),[0,1,2,3]);assert.equal(q.options[q.correct],Q.get(q.id).options[Q.get(q.id).correct]);}
}
ok('1000 sampled exams: exactly 15 unique questions/prompts, 5 tiers x 3, correct option permutations');
reset();let used=new Set();for(let k=0;k<20;k++){let result=take([3,3,3,3,3]);for(const a of result.responses){assert(!used.has(a.qid));used.add(a.qid);}}
assert.equal(used.size,300);assert.equal(S.placementSeen.length,300);ok('20 completed retests: 300 unique exposures, no repeated question');
for(const [scores,expected] of [[[0,0,0,0,0],1],[[3,0,0,0,0],20],[[3,3,0,0,0],40],[[2,2,2,0,0],60],[[3,3,3,2,0],80],[[3,3,3,3,3],100],[[1,3,3,3,3],1],[[3,1,3,3,3],20]]){reset();assert.equal(take(scores).start,expected);}
ok('Conservative recommendations: 1/20/40/60/80/100 and earlier-gap protection');
reset();P.start();const old=P.questionToken(),q=P.current();P.answer(q.correct,old);P.next(old);assert.equal(P.getRun().responses.length,1);P.next(old);P.answer(P.current().correct,old);assert.equal(P.getRun().selection,null);assert.equal(P.getRun().responses.length,1);P.answer(P.current().correct);P.next();assert.equal(P.getRun().responses.length,2);ok('Stale question token and repeated submissions cannot commit another answer');
reset();let result=take([3,3,0,0,0]);let oldRun=result.id;P.accept(oldRun);assert.equal(S.placement.start,40);assert.equal(S.placement.total,15);assert.equal(S.testMode,false);const count=saves;P.accept(oldRun);assert.equal(saves,count);assert.equal(Object.keys(S.best).length,0);ok('Result adoption is idempotent and does not invent formal pass scores');
result=take([3,0,0,0,0]);P.accept();assert.equal(S.placement.start,40);assert.equal(S.placement.suggested,20);ok('Lower retest recommendations do not revoke earlier accepted access');
reset();for(let k=0;k<60;k++){const result=take([3,3,3,3,3]);assert.equal(new Set(result.responses.map(r=>r.qid)).size,15);}assert(S.placementSeen.length<=1000);ok('Exhausted pools recycle least-recently-seen items; never repeat within an exam');
fs.writeFileSync(path.join(root,'tests/placement-report.json'),JSON.stringify({status:'passed',checks},null,2));
