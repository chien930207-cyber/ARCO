"""Validate the shipped question bank and activity schema (no browser required)."""
from pathlib import Path
from collections import Counter
import json

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / 'src/curriculum.json').read_text(encoding='utf-8'))
levels = data['levels']
assert data['version'] == '2.1.0'
assert [item['id'] for item in levels] == list(range(1, 101))
ids = set()
workshops = Counter()
new_count = 0
for lesson in levels:
    assert len(lesson['understand']) == 2 and all(lesson['understand'])
    assert lesson['worked'] and lesson['trap']
    assert len(lesson['mission']['steps']) == 3
    assert all(lesson['mission'][k] for k in ('scene', 'goal', 'check'))
    assert len(lesson['questions']) == 10
    assert len({q['prompt'] for q in lesson['questions']}) == 10
    for question in lesson['questions']:
        assert question['id'] not in ids
        ids.add(question['id'])
        assert len(question['options']) == 4
        assert len(set(question['options'])) == 4
        assert 0 <= question['correct'] < 4
        assert question['explanation']
        new_count += question['id'].startswith('v2-')
    for source in lesson['sources']:
        assert source in data['sources']
        assert data['sources'][source]['url'].startswith('https://')
    w = lesson['workshop']
    workshops[w['kind']] += 1
    if w['kind'] == 'keys':
        assert w['mode'] in ('sequence', 'chord', 'voicing')
        assert all(24 <= n <= 96 for n in w['target'])
    elif w['kind'] == 'rhythm':
        assert all(0 <= n < w['steps'] for n in w['target'])
        assert len(set(w['target'])) == len(w['target'])
        assert w['gridPerBeat'] > 0
    else:
        assert w['answer'] in w['choices']
        assert len(set(w['choices'])) == len(w['choices'])
assert len(ids) == 1000 and new_count == 400
assert sum(workshops.values()) == 100
report = {'status': 'passed', 'version': data['version'], 'levels': len(levels),
          'questions': len(ids), 'new_application_questions': new_count,
          'workshops': dict(workshops), 'content_hash': data['contentHash'],
          'scope': 'Structural validation; not an independent music-teacher review.'}
(ROOT / 'tests/content-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
