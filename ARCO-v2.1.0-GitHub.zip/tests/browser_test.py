"""UI regression suite with DOM injection and test-only memory storage.
Native navigation is blocked by sandbox policy. This harness never changes it.
Shipped HTML is unchanged. LocalStorage restore tests verify serialization only.
Run with: pip install playwright; install Chromium; python tests/browser_test.py
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf-8').replace("if(new URLSearchParams(location.search).has('qa'))",'if(true)')
report={'environment':'DOM-injected Chromium, test-only memory storage. Native navigation blocked with ERR_BLOCKED_BY_ADMINISTRATOR; no policy changes.','checks':[],'errors':[],'requests':[]}
def ok(msg): print('PASS',msg,flush=True);report['checks'].append(msg)
def setup(ctx,raw=None,existing=None):
 p=existing or ctx.new_page();p.set_default_timeout(6000)
 p.on('pageerror',lambda e:report['errors'].append(str(e)))
 p.on('dialog',lambda d:d.accept())
 p.on('request',lambda r:report['requests'].append(r.url))
 p.evaluate("""raw=>{const s={};if(raw)s['arco.learning.v1']=raw;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>s[k]??null,setItem:(k,v)=>s[k]=String(v),removeItem:k=>delete s[k]}})}""",raw)
 p.set_content(HTML,wait_until='domcontentloaded');p.wait_for_timeout(30);return p
def nav(p,route):p.evaluate('(r)=>ARCO.go(r)',route);p.wait_for_timeout(20)
def dismiss(p):
 if p.locator('#welcome').evaluate('(e)=>e.open'):p.locator('#welcome [data-action="placement-skip"]').last.click()
def overflow(p,label):
 dims=p.evaluate('({w:innerWidth,s:document.documentElement.scrollWidth})');assert dims['s']<=dims['w'],(label,dims)
def quiz(p,level,score):
 p.evaluate('(n)=>__ARCO_TEST__.startQuiz(n)',level);p.wait_for_selector('[data-action="answer"]')
 for i in range(10):
  q=p.evaluate('__ARCO_TEST__.getQuiz().questions[__ARCO_TEST__.getQuiz().index]');choice=q['correct'] if i<score else (q['correct']+1)%4
  p.locator(f'[data-action="answer"][data-choice="{choice}"]').click()
  p.locator('[data-action="next-question"]').click()
 p.wait_for_function('__ARCO_TEST__.getQuiz()?.finished===true');assert p.evaluate('__ARCO_TEST__.getQuiz().score')==score
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  ctx=browser.new_context(viewport={'width':1440,'height':1000});p=setup(ctx)
  assert p.locator('#welcome').evaluate('(e)=>e.open');assert p.evaluate('ARCO.getState().testMode') is False
  assert '15' in p.locator('#welcome').inner_text();assert p.locator('header nav svg').count()==4
  p.screenshot(path=str(ROOT/'docs/release-welcome.png'))
  ok('Fresh visitor: 15-question invitation, formal mode, branded SVG navigation')
  p.locator('#welcome [data-action="placement-start"]').click();first=p.evaluate('ArcoPlacement.getRun().questions.map(q=>q.id)')
  for i in range(15):
   assert p.evaluate('ArcoPlacement.getRun().index')==i
   q=p.evaluate('ArcoPlacement.current()')
   assert p.locator('[data-action="placement-next"]').is_disabled()
   if q['tier']<2:p.locator(f'[data-action="placement-answer"][data-choice="{q["correct"]}"]').click()
   else:p.locator('[data-action="placement-unknown"]').click()
   p.locator('[data-action="placement-next"]').click()
  assert p.evaluate('ArcoPlacement.getRun().start')==40
  assert p.evaluate('ArcoPlacement.getRun().responses.length')==15
  assert not p.evaluate('Object.keys(ARCO.getState().best).length')
  p.screenshot(path=str(ROOT/'docs/release-placement-result.png'),full_page=True)
  p.locator('[data-action="placement-accept"]').click();p.wait_for_timeout(30)
  assert p.evaluate('ARCO.getState().placement.start')==40
  assert p.evaluate('Array.from({length:40},(_,i)=>ARCO.accessible(i+1)).every(Boolean)')
  assert not p.evaluate('ARCO.accessible(41)')
  ok('Exactly 15 UI answers recommend 40; accepting opens 1-40 inclusive without pass scores')
  for n in [1,9,20,39,40]:
   nav(p,f'lesson/{n}');assert p.locator('#practice-studio').count()==1;assert '這一級還沒解鎖' not in p.locator('#main').inner_text()
  nav(p,'lesson/41');assert '這一級還沒解鎖' in p.locator('#main').inner_text()
  nav(p,'courses');p.locator('#status-filter').select_option('placement');assert p.locator('#catalog-results .course').count()==40
  p.locator('#chapter-filter').select_option('3');assert p.locator('#catalog-results .course').count()==10
  p.screenshot(path=str(ROOT/'docs/release-course-access.png'))
  ok('Direct lesson routes and catalog filter expose all earlier courses, including level 40')
  quiz(p,10,0);assert p.evaluate('ARCO.accessible(40)');quiz(p,40,7);assert not p.evaluate('ARCO.accessible(41)')
  quiz(p,40,8);assert p.evaluate('ARCO.accessible(41)');assert not p.evaluate('ARCO.accessible(42)')
  ok('Failure never revokes placement access; 7/10 stays, 8/10 opens the next boundary level')
  raw=p.evaluate("localStorage.getItem('arco.learning.v1')");restored=setup(ctx,raw)
  assert not restored.locator('#welcome').evaluate('(e)=>e.open')
  assert restored.evaluate('ARCO.getState().placement.start')==40 and restored.evaluate('ARCO.accessible(41)')
  restored.evaluate('ArcoPlacement.start()');restored.wait_for_timeout(20)
  second=restored.evaluate('ArcoPlacement.getRun().questions.map(q=>q.id)');assert not set(first)&set(second)
  restored.locator('[data-action="placement-cancel"]').click();restored.close()
  ok('Serialized state restores range and pass scores; retest avoids all 15 prior questions')
  candidate=p.evaluate("__ARCO_TEST__.sanitize({placement:{start:41,total:20,correct:17},best:{1:8},testMode:true,placementSeen:['bad','001-01']})")
  assert candidate['placement']['start']==41 and candidate['placement']['total']==20 and candidate['best']['1']==8
  invalid=p.evaluate("__ARCO_TEST__.sanitize({placement:{start:101},placementSeen:['bad'],testMode:'yes'})")
  assert invalid['placement'] is None and invalid['testMode'] is False
  ok('Legacy v2 placement imports and invalid-state sanitization remain compatible')
  # Validate all lesson views without altering earned scores.
  p.evaluate('__ARCO_TEST__.setState({testMode:true})')
  for n in range(1,101):
   nav(p,f'lesson/{n}');assert p.locator('#practice-studio').count()==1;assert p.locator('[data-action="start-quiz"]').count()==1
  ok('100 enriched lessons and practice panels render in the release')
  nav(p,'duel');assert p.locator('.duel-intro').bounding_box()['y']<p.locator('.ai-panel').bounding_box()['y']
  p.clock.install()
  for key in ['easy','normal','hard']:
   p.locator(f'[data-action="duel-ai"][data-profile="{key}"]').click();assert p.evaluate('ArcoDuel.getRoom().mode')=='ai'
   if key!='normal':p.locator('[data-action="duel-leave"]').click();continue
   for i in range(10):
    correct=p.evaluate('ARCO.Q.get(ArcoDuel.getRoom().round.qid).correct')
    p.locator(f'[data-action="duel-answer"][data-choice="{correct}"]').click();p.clock.fast_forward(15000)
    p.wait_for_selector('[data-action="duel-next"]');p.locator('[data-action="duel-next"]').click()
   assert p.evaluate('ArcoDuel.getRoom().status')=='result'
   p.locator('[data-action="duel-rematch"]').click();p.locator('[data-action="duel-leave"]').click()
  ok('Human matchmaking remains above AI; 3 profiles launch, complete AI match and rematch pass')
  p.clock.resume()
  nav(p,'home');p.evaluate('__ARCO_TEST__.setState({testMode:false})');p.evaluate('ARCO.render()')
  p.screenshot(path=str(ROOT/'docs/release-home.png'),full_page=True)
  # Export blob construction and v3 import; not a native file-download claim.
  p.locator('#settings-button').click()
  p.evaluate("""()=>{const orig=URL.createObjectURL;URL.createObjectURL=b=>{window.exported=b.text();return orig(b)};window.originalAnchorClick=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){}}""")
  p.locator('[data-action="export"]').click();out=json.loads(p.evaluate('window.exported'))
  assert out['format']=='arco-progress-v3' and out['state']['placement']['start']==40 and len(out['state']['placementSeen'])==15
  p.evaluate('()=>{HTMLAnchorElement.prototype.click=window.originalAnchorClick}')
  p.locator('#import-file').set_input_files({'name':'progress.json','mimeType':'application/json','buffer':json.dumps(out).encode()});p.wait_for_timeout(40)
  assert p.evaluate('ARCO.getState().best[40]')==8
  ok('Progress export includes exposure history and inclusive access; v3 import preserves both')
  mobile=setup(ctx);mobile.set_viewport_size({'width':390,'height':844});mobile.screenshot(path=str(ROOT/'docs/release-mobile.png'));dismiss(mobile)
  for width in [320,360,390,768]:
   mobile.set_viewport_size({'width':width,'height':844})
   for test in [False,True]:
    mobile.evaluate('(v)=>__ARCO_TEST__.setState({testMode:v})',test)
    for route in ['home','courses','lesson/1','duel','placement']:
     nav(mobile,route);overflow(mobile,f'{width}/{test}/{route}')
   mobile.evaluate('ArcoPlacement.start()');mobile.wait_for_timeout(20);overflow(mobile,f'{width}/exam');mobile.locator('[data-action="placement-cancel"]').click()
  ok('320/360/390/768 px: no page overflow in formal/test mode or placement')
  assert not report['errors'],report['errors'];assert not report['requests'],report['requests']
  ok('No uncaught browser errors or external requests in tested offline/AI flows')
  browser.close()
except Exception as exc:
 report['failure']=repr(exc);print('FAIL',repr(exc),flush=True);raise
finally:
 (ROOT/'tests/browser-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
