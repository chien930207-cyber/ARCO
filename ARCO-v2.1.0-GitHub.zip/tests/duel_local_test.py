"""Chromium DOM/interaction tests. Managed navigation is blocked in this sandbox.
No policy is changed. HTML is injected; storage uses a test-only memory adapter.
The shipped HTML does NOT contain this adapter. Native file reload, downloads,
and cross-device WebRTC must still be tested in a normal browser.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, time
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text().replace("if(new URLSearchParams(location.search).has('qa'))",'if(true)')
report={'environment':'DOM-injected Chromium; memory storage adapter; actual BroadcastChannel transport between opener and popup. Native navigation/storage/download and cross-device internet WebRTC not verified.','checks':[],'errors':[],'requests':[]}
def ok(s):print('PASS',s,flush=True);report['checks'].append(s)
def setup(context,raw=None,existing=None):
 p=existing or context.new_page();p.set_default_timeout(6000)
 p.on('pageerror',lambda e:report['errors'].append(str(e)))
 p.on('dialog',lambda d:d.accept())
 p.on('request',lambda r:report['requests'].append(r.url))
 p.evaluate("""raw=>{const s={};if(raw)s['arco.learning.v1']=raw;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>s[k]??null,setItem:(k,v)=>s[k]=String(v),removeItem:k=>delete s[k]}})}""",raw)
 p.set_content(HTML,wait_until='domcontentloaded');p.wait_for_timeout(40)
 return p
def nav(p,route):
 p.evaluate('(r)=>ARCO.go(r)',route);p.wait_for_timeout(15)
def dismiss(p):
 if p.locator('#welcome').evaluate('(e)=>e.open'):p.locator('[data-action="placement-skip"]').last.click()
def overflow(p,name):
 d=p.evaluate('({w:innerWidth,s:document.documentElement.scrollWidth})');assert d['s']<=d['w'],(name,d)
def quiz(p,level,score):
 p.evaluate('(n)=>__ARCO_TEST__.startQuiz(n)',level);p.wait_for_selector('[data-action="answer"]')
 for i in range(10):
  q=p.evaluate('__ARCO_TEST__.getQuiz().questions[__ARCO_TEST__.getQuiz().index]')
  choice=q['correct'] if i<score else (q['correct']+1)%4
  p.locator(f'[data-action="answer"][data-choice="{choice}"]').click()
  p.locator('[data-action="next-question"]').click()
 p.wait_for_function('__ARCO_TEST__.getQuiz()?.finished===true')
 assert p.evaluate('__ARCO_TEST__.getQuiz().score')==score
 p.wait_for_timeout(20)
def placement(p,correct_below):
 p.evaluate('ArcoPlacement.start()');p.wait_for_selector('[data-action="placement-next"]')
 count=0
 while p.evaluate('ArcoPlacement.getRun().phase')!='result':
  q=p.evaluate('ArcoPlacement.current()')
  choice=q['correct'] if q['band']<correct_below else -1
  p.evaluate('(n)=>ArcoPlacement.answer(n)',choice)
  p.locator('[data-action="placement-next"]').click()
  count+=1;assert count<=20,count
 return p.evaluate('({start:ArcoPlacement.getRun().start,total:ArcoPlacement.getRun().responses.length,correct:ArcoPlacement.getRun().correct,cautious:ArcoPlacement.getRun().cautious})')
with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  ctx=browser.new_context(viewport={'width':1440,'height':1000})
  # Real two-page messaging via inherited about:blank origin, no transport adapter.
  print('local setup',flush=True);host=setup(ctx);dismiss(host)
  with host.expect_popup() as pop:host.evaluate("window.open('')")
  print('popup created',flush=True);guest=setup(ctx,existing=pop.value);dismiss(guest)
  for page in [host,guest]:nav(page,'duel');page.locator('#duel-mode').select_option('local')
  host.locator('#duel-name').fill('Host');host.locator('#duel-level').select_option('70');host.locator('[data-action="duel-create"]').click()
  print('room created',host.evaluate('({status:ArcoDuel.getRoom()?.status,mode:ArcoDuel.getRoom()?.mode,notice:ArcoDuel.getRoom()?.notice})'),flush=True);host.bring_to_front();host.wait_for_function('ArcoDuel.getRoom()?.status==="waiting"',polling=100,timeout=8000);code=host.evaluate('ArcoDuel.getRoom().code');print('code',code,flush=True)
  guest.locator('#duel-name').fill('Guest');guest.locator('#duel-code').fill(code);guest.locator('[data-action="duel-join"]').click()
  print('join sent',guest.evaluate('({status:ArcoDuel.getRoom()?.status,notice:ArcoDuel.getRoom()?.notice})'),flush=True);guest.bring_to_front();guest.wait_for_function('Boolean(ArcoDuel.getRoom()?.otherId)',polling=100,timeout=8000);guest.locator('[data-action="duel-ready"]').click();host.locator('[data-action="duel-start"]').click()
  for i in range(10):
   print('round',i,flush=True)
   for page in [host,guest]:page.wait_for_function(f'ArcoDuel.getRoom()?.status==="playing"&&ArcoDuel.getRoom().index==={i}',polling=100,timeout=8000)
   h=host.evaluate('ArcoDuel.getRoom().round');g=guest.evaluate('ArcoDuel.getRoom().round');assert h['qid']==g['qid'] and h['order']==g['order']
   correct=host.evaluate('ARCO.Q.get(ArcoDuel.getRoom().round.qid).correct')
   host.locator(f'[data-action="duel-answer"][data-choice="{correct}"]').click()
   guest.locator(f'[data-action="duel-answer"][data-choice="{correct if i<7 else (correct+1)%4}"]').click()
   for page in [host,guest]:page.wait_for_selector('[data-action="duel-next"]')
   host.locator('[data-action="duel-next"]').click();assert host.evaluate('ArcoDuel.getRoom().status')=='reveal'
   guest.locator('[data-action="duel-next"]').click()
  for page in [host,guest]:page.wait_for_function('ArcoDuel.getRoom()?.status==="result"',polling=100,timeout=8000)
  assert host.evaluate('ArcoDuel.getRoom().scores')==guest.evaluate('ArcoDuel.getRoom().scores')
  assert host.evaluate('ArcoDuel.getRoom().wins.host')==1
  host.locator('[data-action="duel-rematch"]').click();guest.wait_for_selector('[data-action="duel-ready"]');guest.locator('[data-action="duel-ready"]').click();host.locator('[data-action="duel-start"]').click()
  guest.locator('[data-action="duel-leave"]').click();host.wait_for_function('ArcoDuel.getRoom()?.status==="error"',polling=100,timeout=8000)
  ok('Two real tabs: 10 synchronized questions/options, ready barrier, scores, rematch, disconnect freeze')

  assert not report['errors'],report['errors']
  assert not report['requests'],report['requests']
  (ROOT/'tests/duel-local-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(report,flush=True)
  browser.close()
